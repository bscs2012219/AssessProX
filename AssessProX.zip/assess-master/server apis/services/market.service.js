const marketmodel = require('../model/market.modal');

class marketService{
    static async registermarket(title,price,des,url,number,users){
         try{
             const cretemarket = new marketmodel({title,price,des,url,number,users});
             return await cretemarket.save();
         } catch(e){
             res.json({status:false,sucess:"server error service register"});
         }
    }

    static async getallmarket(){
        try{
            return await marketmodel.find();
        } catch(e){
            console.log(e)
                res.json({status:false,sucess:"server error service chcekuser"});
        }
    }

    static async updateusers(id,users){
        try{
            return await marketmodel.findByIdAndUpdate(id,{$set:{users:users}});
        } catch(e){
            console.log(e)
                res.json({status:false,sucess:"server error service chcekuser"});
        }
    }

}
 
module.exports = marketService;
