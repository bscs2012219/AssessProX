const pinmodel = require('../model/pin.modal');

class PinService{
    static async registerpin(pintitle,pin){
         try{
             const cretepin = new pinmodel({pintitle,pin});
             return await cretepin.save();
         } catch(e){
             console.log(e)
             res.json({status:false,sucess:"server error service register"});
         }
    }

    static async getpin(){
        try{
            return await pinmodel.find();
        } catch(e){
            console.log(e)
                res.json({status:false,sucess:"server error service chcekuser"});
        }
    }

    static async updatepin(pintitle){
        try{
            return await pinmodel.findOneAndUpdate(
                { pintitle: pintitle },
                { $inc: { pin: 1 } },
                { new: true } 
            );
        } catch(e){
            console.log(e)
                res.json({status:false,sucess:"server error service chcekuser"});
        }
    }

}
 
module.exports = PinService;