const quizmodel = require('../model/quiz.modal');

class QuizService{
    static async registerquiz(title,des,pin,subject,duration,questionanswer,user){
         try{
             const cretequiz = new quizmodel({title,des,pin,subject,duration,questionanswer,user});
             return await cretequiz.save();
         } catch(e){
             console.log(e)
             res.json({status:false,sucess:"server error service register"});
         }
    }

    static async checkquiz(){
        try{
            return await quizmodel.find();
        } catch(e){
            console.log(e)
                res.json({status:false,sucess:"server error service chcekuser"});
        }
    }

    static async getonequiz(pin){
        try{
            return await quizmodel.findOne({pin});
        } catch(e){
            console.log(e)
                res.json({status:false,sucess:"server error service chcekuser"});
        }
    }

    static async getquizbysubject(subject){
        try{
            return await quizmodel.find({subject});
        } catch(e){
            console.log(e)
                res.json({status:false,sucess:"server error service chcekuser"});
        }
    }

    static async updateusers(pin){
        try{
            return await quizmodel.findOneAndUpdate(
                { pin: pin },
                { $inc: { user: 1 } },
                { new: true } 
            );
        } catch(e){
            console.log(e)
                res.json({status:false,sucess:"server error service chcekuser"});
        }
    }

}
 
module.exports = QuizService;