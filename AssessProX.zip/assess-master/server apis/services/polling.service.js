const pollingmodel = require('../model/polling.modal');

class PollingService{
    static async registerpoll(username,usernumber,quizpin,quiznumber,date){
         try{
             const cretepoll = new pollingmodel({username,usernumber,quizpin,quiznumber,date});
             return await cretepoll.save();
         } catch(e){
             console.log(e)
             res.json({status:false,sucess:"server error service register"});
         }
    }

    static async getbyuser(usernumber){
        try{
            return await pollingmodel.find({usernumber});
        } catch(e){
            console.log(e)
                res.json({status:false,sucess:"server error service chcekuser"});
        }
    }

    static async getbynumber(quizpin){
        try{
            return await pollingmodel.find({quizpin}).sort({ quiznumber: -1 });
        } catch(e){
            console.log(e)
                res.json({status:false,sucess:"server error service chcekuser"});
        }
    }

}
 
module.exports = PollingService;