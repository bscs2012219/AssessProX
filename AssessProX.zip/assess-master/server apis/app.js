const express = require("express");
const bodyParser = require("body-parser")
const UserRoute = require("./routers/user.route");
const quizRoute = require("./routers/quiz.route");
const pinRoute = require("./routers/pin.route");
const pollRoute = require("./routers/polling.route");
const marketRoute = require("./routers/market.route");
const walletRoute = require("./routers/wallet.route");
const mocktestRoute = require("./routers/mocktest.route");
const classRoute = require("./routers/class.route");

const app = express();
app.use(bodyParser.json());
app.use("/",UserRoute);
app.use("/",quizRoute);
app.use("/",pinRoute);
app.use("/",pollRoute);
app.use("/",marketRoute);
app.use("/",walletRoute);
app.use("/",mocktestRoute);
app.use("/",classRoute);

module.exports = app;
