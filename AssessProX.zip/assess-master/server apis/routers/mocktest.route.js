const mocktestmodel = require('../model/mocktest.modal');
const app = require('express').Router();

app.post('/registermocktest', async (req, res, next) => {
    try {
      const { addedby, pdf, title, des } = req.body;
      const newChat = new mocktestmodel({ addedby, pdf, title, des });
      await newChat.save();
      res.status(200).json({ status: true, message: 'register sucessfully' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ status: false, message: 'try again later' });
    }
});

app.post('/allmocktest', async (req, res, next) => {
    try {
      const user = await mocktestmodel.find();
      res.status(200).json({ status:true ,data:user});
    } catch (error) {
      console.log(error);
      res.status(500).json({ status:false,data:[] });
    }
});

module.exports = app;