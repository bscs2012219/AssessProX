const router = require('express').Router();
const pinController = require('../controller/pin.controller');

router.post("/registerpin",pinController.registerpin);
router.post("/getpin",pinController.getpin);

module.exports = router;
