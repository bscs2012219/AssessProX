const classmodel = require('../model/class.modal');
const app = require('express').Router();

app.post('/registerclass', async (req, res, next) => {
    try {
      const { addedby, title, des, code, user, chat } = req.body;
      const newChat = new classmodel({ addedby, title, des, code, user, chat });
      await newChat.save();
      res.status(200).json({ status: true, message: 'register sucessfully' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ status: false, message: 'try again later' });
    }
});

app.post('/allclass', async (req, res, next) => {
    try {
      const user = await classmodel.find();
      res.status(200).json({ status:true ,data:user});
    } catch (error) {
      console.log(error);
      res.status(500).json({ status:false,data:[] });
    }
});

app.post('/classbyid', async (req, res, next) => {
    try {
      const { id } = req.body;
      const user = await classmodel.findById(id);
      res.status(200).json({ status:true ,data:user});
    } catch (error) {
      console.log(error);
      res.status(500).json({ status:false,data:[] });
    }
});


app.post('/classaddchat', async (req, res, next) => {
    try {
      const { id,data } = req.body;
      const user = await classmodel.findById(id);
      user.chat.push(data);
      await classmodel.findByIdAndUpdate(id, { $set: { chat: user.chat } })
      res.status(200).json({ status:true});
    } catch (error) {
      console.log(error);
      res.status(500).json({ status:false});
    }
});

app.post('/classjoin', async (req, res, next) => {
    try {
      const { id,usernum } = req.body;
      const user = await classmodel.findById(id);
      if (!user.user.includes(usernum)) {
        user.user.push(usernum);
        await classmodel.findByIdAndUpdate(id, { $set: { user: user.user } })   
      }
      res.status(200).json({ status:true});
    } catch (error) {
      console.log(error);
      res.status(500).json({ status:false});
    }
});


app.post('/classjoinbycode', async (req, res, next) => {
    try {
      const { code,usernum,  } = req.body;
      const user = await classmodel.findOne({ code: code });
      if (user.addedby !== usernum) {
        if (!user.user.includes(usernum)) {
            user.user.push(usernum);
            await classmodel.findByIdAndUpdate(id, { $set: { user: user.user } })   
          }   
      }
      res.status(200).json({ status:true, a:user});
    } catch (error) {
      console.log(error);
      res.status(500).json({ status:false, a:{}});
    }
});

module.exports = app;
