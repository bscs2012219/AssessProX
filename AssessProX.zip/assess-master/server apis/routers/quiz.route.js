const router = require('express').Router();
const quizController = require('../controller/quiz.controller');

router.post("/registerquiz",quizController.registerquiz);
router.post("/getquiz",quizController.getquiz);
router.post("/getonequiz",quizController.getonequiz);
router.post("/updateusers",quizController.updateusers);
router.post("/getquizbysubject",quizController.getquizbysubject);

module.exports = router;
