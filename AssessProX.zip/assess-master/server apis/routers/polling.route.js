const router = require('express').Router();
const pollController = require('../controller/polling.controller');

router.post("/registerpoll",pollController.registerpoll);
router.post("/getpollbyuser",pollController.getpollbyuser);
router.post("/getpollbynumber",pollController.getpollbynumber);

module.exports = router;
