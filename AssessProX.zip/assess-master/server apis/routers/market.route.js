const router = require('express').Router();
const marketController = require('../controller/market.controller');

router.post("/registermarket",marketController.registermarket);
router.post("/getallmarket",marketController.getallmarket);
router.post("/updatemarket",marketController.updatemarket);
router.post("/getallmarketbynumber",marketController.getallmarketbynumber);

module.exports = router;
