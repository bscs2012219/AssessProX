const router = require('express').Router();
const userController = require('../controller/user.controller');

router.post("/register",userController.register);
router.post("/login",userController.login);
router.post("/userbynum",userController.userdata);
router.post("/oneuserdata",userController.oneuserdata);
router.post("/alluser",userController.alluser);

module.exports = router;
