const mongoose = require('mongoose');
const db = require('../config/db');

const { Schema } = mongoose;

const pollingSchema = new Schema({
    username:{
        type:String,
        require:true
    },
    usernumber:{
        type:String,
        require:true
    },
    quizpin:{
        type:String,
        require:true
    },
    quiznumber:{
        type:String,
        require:true
    },
    date:{
        type:String,
    },
});

const pollingModel = db.model('polling',pollingSchema);
module.exports = pollingModel;
