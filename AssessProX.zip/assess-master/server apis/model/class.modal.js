const mongoose = require('mongoose');
const db = require('../config/db');

const { Schema } = mongoose;

const classSchema = new Schema({
    addedby:{
        type:String,
    },
    title:{
        type:String,
    },
    des:{
        type:String,
    },
    code:{
        type:String,
    },
    user:[],
    chat:[],
});

const classModel = db.model('class',classSchema);
module.exports = classModel;
