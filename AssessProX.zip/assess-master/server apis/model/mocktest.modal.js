const mongoose = require('mongoose');
const db = require('../config/db');

const { Schema } = mongoose;

const mocktestSchema = new Schema({
    addedby:{
        type:String,
    },
    pdf:{
        type:String,
    },
    title:{
        type:String,
    },
    des:{
        type:String,
    },
});

const mocktestModel = db.model('mocktest',mocktestSchema);
module.exports = mocktestModel;
