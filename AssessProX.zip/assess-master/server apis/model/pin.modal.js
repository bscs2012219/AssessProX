const mongoose = require('mongoose');
const db = require('../config/db');

const { Schema } = mongoose;

const pinSchema = new Schema({
    pintitle:{
        type:String,
        require:true
    },
    pin:{
        type:Number,
        require:true
    },
});

const pinModel = db.model('pin',pinSchema);
module.exports = pinModel;
