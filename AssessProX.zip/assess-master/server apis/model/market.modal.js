const mongoose = require('mongoose');
const db = require('../config/db');

const { Schema } = mongoose;

const marketSchema = new Schema({
    title:{
        type:String,
        require:true
    },
    price:{
        type:String,
        require:true
    },
    des:{
        type:String,
        require:true
    },
    number:{
        type:String,
        require:true
    },
    url:[
        {
            type:String,
        }
    ],
    users:[
        {
            type:String,
        }
    ]
});

const marketModel = db.model('market',marketSchema);
module.exports = marketModel;
