const mongoose = require('mongoose');
const db = require('../config/db');

const { Schema } = mongoose;

const quizSchema = new Schema({
    title:{
        type:String,
        require:true
    },
    des :{
        type:String,
        require:true
    },
    pin:{
        type:String,
        require:true
    },
    subject:{
        type:String,
        require:true
    },
    duration:{
        type:String,
        require:true
    },
    questionanswer:{
        type:[],
        require:true
    },
    user:{
        type:Number,
        require:true
    },
});

const QuizModel = db.model('quiz',quizSchema);
module.exports = QuizModel;
