const quizService = require('../services/quiz.service');

exports.registerquiz = async(req,res,next)=>{
    try{
        const {title,des,pin,subject,duration,questionanswer,user} = req.body;
        const response = await quizService.registerquiz(title,des,pin,subject,duration,questionanswer,user);
        res.json({status:true,sucess:"Quiz registered Sucessfully"});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller register"});
    }
}

exports.getquiz = async(req,res,next)=>{
    try{
        const {} = req.body;
        
        const quiz = await quizService.checkquiz();
        if(!quiz){
            res.status(200).json({status:false,message:"no quiz found"});
        } else{
            res.status(200).json({status:true,data:quiz,message:"quiz fetch sucessfully"});
        }
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}


exports.getonequiz = async(req,res,next)=>{
    try{
        const {pin} = req.body;
        
        const quiz = await quizService.getonequiz(pin);
        if(!quiz){
            res.status(200).json({status:false,message:"no quiz found"});
        } else{
            res.status(200).json({status:true,data:quiz,message:"quiz fetch sucessfully"});
        }
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}

exports.updateusers = async(req,res,next)=>{
    try{
        const {pin} = req.body;
        
        const quiz = await quizService.updateusers(pin);
        res.status(200).json({status:true,message:"ok"});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}


exports.getquizbysubject = async(req,res,next)=>{
    try{
        const {subject} = req.body;
        
        const quiz = await quizService.getquizbysubject(subject);
        res.status(200).json({status:true,data:quiz,message:"ok"});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}
