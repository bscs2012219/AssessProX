const marketService = require('../services/market.service');

exports.registermarket = async(req,res,next)=>{
    try{
        const {title,price,des,url,number,users} = req.body;
        const response = await marketService.registermarket(title,price,des,url,number,users);
        res.json({status:true,sucess:"market good registered Sucessfully"});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller register"});
    }
}

exports.getallmarket = async(req,res,next)=>{
    try{
        const market = await marketService.getallmarket();
        res.status(200).json({market:market});
    } catch (e){
        res.json({status:false,sucess:"server error controller login"});
    }
}

exports.updatemarket = async(req,res,next)=>{
    try{
        const {id,users} = req.body;
        await marketService.updateusers(id,users);
        res.status(200).json({status:true});
    } catch (e){
        res.json({status:false,sucess:"server error controller login"});
    }
}


exports.getallmarketbynumber = async(req,res,next)=>{
    try{
        const {number} = req.body;
        const market = await marketService.getallmarket();
        let f = [];
        for (let i = 0; i < market.length; i++) {
            const item = market[i];
            for (let j = 0; j < item.users.length; j++) {
                const item2 = item.users[j];
                if(item2 === number){
                    f.push(item);
                    break;
                }
            }
        }
        res.status(200).json({market:f});
    } catch (e){
        res.json({status:false,sucess:"server error controller login"});
    }
}