const pollService = require('../services/polling.service');
const userService = require('../services/user.service');

exports.registerpoll = async(req,res,next)=>{
    try{
        const {username,usernumber,quizpin,quiznumber,date,streak} = req.body;
        const response = await pollService.registerpoll(username,usernumber,quizpin,quiznumber,date,streak);
        const user = await userService.checkuser(usernumber);
        let points = parseInt(user.points)+parseInt(quiznumber)+parseInt(streak);
        let streakf = parseInt(user.streak);
        if(parseInt(streak) == 0){
            streakf = 0;
        } else {
            streakf = parseInt(streak)+parseInt(user.streak);
        }
        await userService.updatepoint(usernumber,points,streakf);
        res.json({status:true,sucess:"Poll registered Sucessfully"});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller register"});
    }
}

exports.getpollbyuser = async(req,res,next)=>{
    try{
        const {usernumber} = req.body;
        
        const poll = await pollService.getbyuser(usernumber);
        if(!poll){
            res.status(200).json({status:false,message:"no poll found"});
        } else{
            res.status(200).json({status:true,data:poll,message:"poll fetch sucessfully"});
        }
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}


exports.getpollbynumber = async(req,res,next)=>{
    try{
        const {quizpin} = req.body;
        
        const poll = await pollService.getbynumber(quizpin);
        if(!poll){
            res.status(200).json({status:false,message:"no poll found"});
        } else{
            res.status(200).json({status:true,data:poll,message:"poll fetch sucessfully"});
        }
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}