const UserService = require('../services/user.service');

exports.register = async(req,res,next)=>{
    try{
        const {number,name,img,cnic,pass,address,lastdeg,subject,dob,deviceid,points,streak} = req.body;
        await UserService.registerUser(number,name,img,cnic,pass,address,lastdeg,subject,dob,deviceid,points,streak);
        res.json({status:true,sucess:"User registered Sucessfully"});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller register"});
    }
}


exports.login = async(req,res,next)=>{
    try{
        const {number,pass,deviceid} = req.body;
        
        const user = await UserService.checkuser(number);
        if(!user){
            res.status(200).json({status:false,message:"no user found"});
        } else{

            const isMatch = await user.comparePassword(pass);
            if(isMatch == false){
                res.status(200).json({status:false,message:"invalid password"});
            } else{
                await UserService.updatedevice(user._id, deviceid);
                let tokenData = {user};
                const token = await UserService.generateToken(tokenData,"learnandearn","1h")
                res.status(200).json({status:true,token:token,message:"login in sucessfully"});
            }
        }
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}


exports.userdata = async(req,res,next)=>{
    try{
        const {number,pass,deviceid} = req.body;
        
        const user = await UserService.checkuser(number);
        if(!user){
            res.status(200).json({status:false,message:"no user found"});
        } else{
            res.status(200).json({status:true,img:user.img});
        }
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}


exports.oneuserdata = async(req,res,next)=>{
    try{
        const {number} = req.body;
        
        const user = await UserService.checkuser(number);    
        res.status(200).json({status:true,data:user});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}


exports.alluser = async(req,res,next)=>{
    try{
        const user = await UserService.alluser();    
        res.status(200).json({status:true,data:user});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}