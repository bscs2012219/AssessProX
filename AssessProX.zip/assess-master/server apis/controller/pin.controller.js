const pinService = require('../services/pin.service');

exports.registerpin = async(req,res,next)=>{
    try{
        const {pintitle,pin} = req.body;
        const response = await pinService.registerpin(pintitle,pin);
        res.json({status:true,sucess:"Quiz registered Sucessfully"});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller register"});
    }
}

exports.getpin = async(req,res,next)=>{
    try{
        const {} = req.body;
        
        const pin = await pinService.getpin();
        if(!pin){
            res.status(200).json({status:false,message:"no pin found"});
        } else{
            const npin = await pinService.updatepin('0')
            res.status(200).json({pin:npin.pin});
        }
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}
