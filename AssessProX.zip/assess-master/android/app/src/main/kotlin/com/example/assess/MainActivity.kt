package com.example.assess

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
