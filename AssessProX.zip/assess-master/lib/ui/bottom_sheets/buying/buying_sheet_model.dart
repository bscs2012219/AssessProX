import 'package:stacked/stacked.dart';

class BuyingSheetModel extends BaseViewModel {}
