import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:assess/ui/common/uihelper/button_helper.dart';
import 'package:assess/ui/common/uihelper/snakbar_helper.dart';
import 'package:flutter/material.dart';
import 'package:image_gallery_saver/image_gallery_saver.dart';
import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/ui_helpers.dart';
import 'package:flutter/rendering.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../common/app_strings.dart';
import '../../common/uihelper/text_helper.dart';
import '../../widgets/common/quizlistimg/quizlistimg.dart';
import '../../widgets/common/quizlistinnerdata/quizlistinnerdata.dart';
import 'notice_sheet_model.dart';

class NoticeSheet extends StackedView<NoticeSheetModel> {
  final Function(SheetResponse)? completer;
  final SheetRequest request;
  const NoticeSheet({
    Key? key,
    required this.completer,
    required this.request,
  }) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    NoticeSheetModel viewModel,
    Widget? child,
  ) {
    GlobalKey _globalKey = GlobalKey();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(10),
          topRight: Radius.circular(10),
        ),
      ),
      child: ListView(
        children: [
          text_helper(
            data: request.data['title'].toString().toUpperCase(),
            font: poppins,
            color: kcPrimaryColor,
            size: fontSize12,
            bold: true,
          ),
          verticalSpaceSmall,
          RepaintBoundary(
            key: _globalKey,
            child: Container(
              color: white,
              child: Quizlistimg(
                information: request.data['pin'],
                size: 0.5,
              ),
            ),
          ),
          verticalSpaceMedium,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Quizlistinnerdata(
                txt: request.data['subject'].toString().toUpperCase(),
                iconData: "assets/subject.png",
                width: 0.1,
              ),
              Quizlistinnerdata(
                txt: request.data['duration'].toString().toUpperCase(),
                iconData: "assets/duration.png",
                width: 0.1,
              ),
              Quizlistinnerdata(
                  txt: request.data['questionanswer'].length
                      .toString()
                      .toUpperCase(),
                  width: 0.1,
                  iconData: "assets/questions.png"),
              Quizlistinnerdata(
                txt: request.data['user'].toString().toUpperCase(),
                iconData: "assets/user.png",
                width: 0.1,
              ),
            ],
          ),
          verticalSpaceSmall,
          text_helper(
            data: request.data['des'].toString().toUpperCase(),
            font: poppins,
            color: kcLightGrey,
            size: fontSize10,
            bold: true,
          ),
          button_helper(
              onpress: () async {
                RenderRepaintBoundary boundary = _globalKey.currentContext!
                    .findRenderObject() as RenderRepaintBoundary;
                ui.Image image = await boundary.toImage(pixelRatio: 3.0);
                ByteData? byteData =
                    await image.toByteData(format: ui.ImageByteFormat.png);
                Uint8List uint8List = byteData!.buffer.asUint8List();
                await ImageGallerySaver.saveImage(uint8List);
                Navigator.pop(context);
                show_snackbar(context, "Qr Saved");
              },
              color: kcPrimaryColor,
              width: screenWidth(context),
              child: text_helper(
                  data: "Download Qr",
                  font: poppins,
                  color: white,
                  bold: true,
                  size: fontSize14))
        ],
      ),
    );
  }

  @override
  NoticeSheetModel viewModelBuilder(BuildContext context) => NoticeSheetModel();
}
