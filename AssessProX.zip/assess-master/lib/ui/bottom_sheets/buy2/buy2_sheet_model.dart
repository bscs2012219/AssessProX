import 'package:stacked/stacked.dart';

class Buy2SheetModel extends BaseViewModel {}
