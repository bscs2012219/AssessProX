import 'package:stacked/stacked.dart';

class BuySheetModel extends BaseViewModel {}
