import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';

class InfoAlertDialogModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();

  final GlobalKey globalKey = GlobalKey();
  int count = 0;
  String pin = '';

  void back() {
    _navigationService.back(result: DialogResponse(data: {"pin": pin}));
  }
}
