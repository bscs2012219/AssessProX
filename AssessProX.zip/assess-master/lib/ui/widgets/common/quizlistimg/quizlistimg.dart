// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_colors.dart';
import '../../../common/ui_helpers.dart';
import 'quizlistimg_model.dart';

class Quizlistimg extends StackedView<QuizlistimgModel> {
  Quizlistimg({super.key, required this.information, required this.size});
  String information;
  double size;

  @override
  Widget builder(
    BuildContext context,
    QuizlistimgModel viewModel,
    Widget? child,
  ) {
    return Container(
        padding: const EdgeInsets.all(1),
        decoration: BoxDecoration(
            color: getColorWithOpacity(golden, 0.1),
            borderRadius: BorderRadius.circular(10)),
        child: Center(
          child: QrImageView(
            data: information,
            version: QrVersions.auto,
            size: screenWidthCustom(context, size),
          ),
        ));
  }

  @override
  QuizlistimgModel viewModelBuilder(
    BuildContext context,
  ) =>
      QuizlistimgModel();
}
