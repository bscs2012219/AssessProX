import 'package:stacked/stacked.dart';

class QuizlistimgModel extends BaseViewModel {}
