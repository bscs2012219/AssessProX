// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_colors.dart';
import '../../../common/app_strings.dart';
import '../../../common/ui_helpers.dart';
import '../../../common/uihelper/text_helper.dart';
import 'quizlistinnerdata_model.dart';

class Quizlistinnerdata extends StackedView<QuizlistinnerdataModel> {
  Quizlistinnerdata(
      {super.key,
      required this.txt,
      required this.iconData,
      this.width = 0.06});
  String txt;
  String iconData;
  double width;

  @override
  Widget builder(
    BuildContext context,
    QuizlistinnerdataModel viewModel,
    Widget? child,
  ) {
    return Row(
      children: [
        Image.asset(
          iconData,
          width: screenWidthCustom(context, width),
          height: screenWidthCustom(context, width),
        ).animate(delay: 1700.ms).fade().moveY(begin: 50, end: 0),
        horizontalSpaceTiny,
        text_helper(
                data: txt,
                font: poppins,
                color: kcDarkGreyColor,
                bold: true,
                size: fontSize12)
            .animate(delay: 1900.ms)
            .fade()
            .moveY(begin: 50, end: 0),
      ],
    );
  }

  @override
  QuizlistinnerdataModel viewModelBuilder(
    BuildContext context,
  ) =>
      QuizlistinnerdataModel();
}
