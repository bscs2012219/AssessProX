import 'package:stacked/stacked.dart';

class QuizlistinnerdataModel extends BaseViewModel {}
