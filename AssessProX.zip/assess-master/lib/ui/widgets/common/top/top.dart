import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/app_strings.dart';
import 'package:assess/ui/common/ui_helpers.dart';
import 'package:assess/ui/common/uihelper/text_helper.dart';
import 'package:assess/ui/widgets/common/tophelper/tophelper.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import 'top_model.dart';

class Top extends StackedView<TopModel> {
  Top({super.key, required this.title, this.isback = true});
  String title;
  bool isback;

  @override
  Widget builder(
    BuildContext context,
    TopModel viewModel,
    Widget? child,
  ) {
    return Container(
      width: screenWidth(context),
      padding: const EdgeInsets.all(10),
      margin: const EdgeInsets.all(10),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: getColorWithOpacity(kcLightGrey, 0.1)),
      child: Row(
        children: [
          isback
              ? Tophelper(
                  function: () => viewModel.back(), icon: "assets/arrowb.png")
              : const SizedBox.shrink(),
          horizontalSpaceSmall,
          text_helper(
            data: title,
            font: poppins,
            color: kcPrimaryColor,
            size: fontSize14,
            bold: true,
          )
        ],
      ),
    );
  }

  @override
  TopModel viewModelBuilder(
    BuildContext context,
  ) =>
      TopModel();
}
