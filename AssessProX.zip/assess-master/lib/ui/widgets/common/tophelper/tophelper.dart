// ignore_for_file: must_be_immutable

import 'package:assess/ui/common/app_strings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_colors.dart';
import '../../../common/ui_helpers.dart';
import '../../../common/uihelper/text_helper.dart';
import 'tophelper_model.dart';

class Tophelper extends StackedView<TophelperModel> {
  Tophelper(
      {super.key, required this.function, required this.icon, this.text = ""});
  Function function;
  String icon;
  String text;

  @override
  Widget builder(
    BuildContext context,
    TophelperModel viewModel,
    Widget? child,
  ) {
    return text == ''
        ? InkWell(
            onTap: () => function(),
            child: Container(
              padding: const EdgeInsets.all(5),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                // color: white,
              ),
              child: Image.asset(
                icon,
                width: screenWidthCustom(context, 0.08),
                height: screenWidthCustom(context, 0.08),
              ).animate(delay: 700.ms).fade().moveY(begin: 50, end: 0),
            ).animate(delay: 500.ms).fade().moveY(begin: 50, end: 0),
          )
        : Expanded(
            child: InkWell(
              onTap: () => function(),
              child: Container(
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: getColorWithOpacity(golden, 0.1),
                ),
                child: Column(
                  children: [
                    Image.asset(
                      icon,
                      width: screenWidthCustom(context, 0.12),
                      height: screenWidthCustom(context, 0.12),
                    ).animate(delay: 700.ms).fade().moveY(begin: 50, end: 0),
                    verticalSpaceTiny,
                    text_helper(
                      data: text,
                      font: montserrat,
                      color: kcDarkGreyColor,
                      size: fontSize12,
                    ).animate(delay: 800.ms).fade().moveY(begin: 50, end: 0),
                  ],
                ),
              ).animate(delay: 500.ms).fade().moveY(begin: 50, end: 0),
            ),
          );
  }

  @override
  TophelperModel viewModelBuilder(
    BuildContext context,
  ) =>
      TophelperModel();
}
