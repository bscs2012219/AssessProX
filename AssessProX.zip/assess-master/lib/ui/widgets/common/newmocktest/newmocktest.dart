import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/app_strings.dart';
import 'package:assess/ui/common/uihelper/button_helper.dart';
import 'package:assess/ui/common/uihelper/text_helper.dart';
import 'package:assess/ui/common/uihelper/text_veiw_helper.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../../common/ui_helpers.dart';
import 'newmocktest_model.dart';

class Newmocktest extends StackedView<NewmocktestModel> {
  const Newmocktest({super.key});

  @override
  Widget builder(
    BuildContext context,
    NewmocktestModel viewModel,
    Widget? child,
  ) {
    return Container(
      width: screenWidth(context),
      decoration:
          BoxDecoration(borderRadius: BorderRadius.circular(10), color: white),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          verticalSpaceSmall,
          text_helper(
              data: "New Mock Test",
              font: poppins,
              color: kcDarkGreyColor,
              size: fontSize18,
              bold: true),
          verticalSpaceSmall,
          InkWell(
              onTap: () => viewModel.pickPdfFile(),
              child: Container(
                width: screenWidth(context),
                padding: const EdgeInsets.all(10),
                margin: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: white,
                    border: Border.all(color: kcPrimaryColor, width: 1)),
                child: text_helper(
                    data: viewModel.selectedFile == null
                        ? "Select A PDF"
                        : viewModel.selectedFile!.path.split('/').last,
                    font: poppins,
                    color: kcDarkGreyColor,
                    size: fontSize14),
              )),
          text_view_helper(
            hint: "Enter Title",
            controller: viewModel.name,
            showicon: true,
            icon: const Icon(Icons.title),
          ),
          text_view_helper(
            hint: "Enter Description",
            controller: viewModel.description,
            showicon: true,
            icon: const Icon(Icons.title),
          ),
          verticalSpaceSmall,
          button_helper(
              onpress: () => viewModel.add(context),
              color: kcPrimaryColor,
              width: screenWidth(context),
              child: text_helper(
                  data: "Add",
                  font: poppins,
                  color: white,
                  size: fontSize14,
                  bold: true))
        ],
      ),
    );
  }

  @override
  NewmocktestModel viewModelBuilder(
    BuildContext context,
  ) =>
      NewmocktestModel();
}
