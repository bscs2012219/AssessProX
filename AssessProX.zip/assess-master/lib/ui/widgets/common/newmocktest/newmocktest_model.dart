import 'dart:io';

import 'package:assess/ui/common/apihelpers/apihelper.dart';
import 'package:assess/ui/common/apihelpers/firebsaeuploadhelper.dart';
import 'package:assess/ui/common/uihelper/snakbar_helper.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';

import '../../../../app/app.locator.dart';
import '../../../../services/sharedpref_service.dart';

class NewmocktestModel extends BaseViewModel {
  final sharedpref = locator<SharedprefService>();

  TextEditingController name = TextEditingController();
  TextEditingController description = TextEditingController();

  File? selectedFile;

  Future<void> pickPdfFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );

    if (result != null) {
      selectedFile = File(result.files.single.path!);
      notifyListeners();
    }
  }

  Future<void> add(BuildContext context) async {
    if (name.text.isEmpty || description.text.isEmpty) {
      show_snackbar(context, "Please fill all fields");
    } else if (selectedFile == null) {
      show_snackbar(context, "Please select a pdf file");
    } else {
      displayprogress(context);
      String url = await FirebaseHelper.uploadFile(
          selectedFile, sharedpref.readString('number'));
      bool c = await ApiHelper.registermocktest(sharedpref.readString('number'),
          url, name.text, description.text, context);
      hideprogress(context);
      if (c) {
        show_snackbar(context, "Test added successfully");
        Navigator.pop(context);
      } else {
        show_snackbar(context, "Something went wrong");
      }
    }
  }
}
