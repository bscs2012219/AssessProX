import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/app_strings.dart';
import 'package:assess/ui/common/ui_helpers.dart';
import 'package:assess/ui/common/uihelper/text_helper.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:stacked/stacked.dart';

import '../../../common/apihelpers/apihelper.dart';
import '../../../common/uihelper/snakbar_helper.dart';
import '../quizlistimg/quizlistimg.dart';
import 'recomendedquiz_model.dart';

class Recomendedquiz extends StackedView<RecomendedquizModel> {
  const Recomendedquiz({super.key});

  @override
  Widget builder(
    BuildContext context,
    RecomendedquizModel viewModel,
    Widget? child,
  ) {
    return Container(
      width: screenWidth(context),
      height: 160,
      margin: const EdgeInsets.symmetric(horizontal: 10),
      child: FutureBuilder(
          future: ApiHelper.getquizbysubject(
              viewModel.sharedpref.readString("subject")),
          builder: (BuildContext context, AsyncSnapshot snapshot) {
            if (snapshot.hasData) {
              return ListView.builder(
                itemCount: snapshot.data.length,
                scrollDirection: Axis.horizontal,
                itemBuilder: (BuildContext context, int index) {
                  return InkWell(
                    onTap: () => viewModel.next(snapshot.data[index]),
                    child: Container(
                      width: 200,
                      margin: const EdgeInsets.all(10),
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Quizlistimg(
                                information: snapshot.data[index]['pin'],
                                size: 0.15,
                              )
                                  .animate(delay: 1300.ms)
                                  .fade()
                                  .moveY(begin: 50, end: 0),
                              horizontalSpaceTiny,
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  text_helper(
                                          data: snapshot.data[index]['subject'],
                                          bold: true,
                                          font: poppins,
                                          color: kcPrimaryColor,
                                          size: fontSize14)
                                      .animate(delay: 1500.ms)
                                      .fade()
                                      .moveY(begin: 50, end: 0),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                              padding: const EdgeInsets
                                                  .symmetric(horizontal: 5),
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  border: Border.all(
                                                      width: 2,
                                                      color: kcVeryLightGrey)),
                                              child: Row(
                                                children: [
                                                  const Icon(
                                                    Icons.person,
                                                    color: kcPrimaryColor,
                                                    size: 20,
                                                  ),
                                                  text_helper(
                                                      data: snapshot.data[index]
                                                              ['user']
                                                          .toString(),
                                                      font: poppins,
                                                      color: kcDarkGreyColor,
                                                      size: fontSize14),
                                                ],
                                              ))
                                          .animate(delay: 1700.ms)
                                          .fade()
                                          .moveY(begin: 50, end: 0),
                                      horizontalSpaceSmall,
                                      text_helper(
                                              data:
                                                  "${snapshot.data[index]['duration']} min",
                                              bold: true,
                                              font: poppins,
                                              color: kcDarkGreyColor,
                                              size: fontSize10)
                                          .animate(delay: 1900.ms)
                                          .fade()
                                          .moveY(begin: 50, end: 0),
                                    ],
                                  )
                                ],
                              )
                            ],
                          ),
                          verticalSpaceSmall,
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              InkWell(
                                onTap: () => viewModel
                                    .leaderboard(snapshot.data[index]['pin']),
                                child: Container(
                                  padding: const EdgeInsets.all(5),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: getColorWithOpacity(
                                          kcPrimaryColor, 0.2)),
                                  child: Image.asset(
                                    "assets/leaderboardicon.png",
                                    width: screenWidthCustom(context, 0.08),
                                    height: screenWidthCustom(context, 0.08),
                                  )
                                      .animate(delay: 2300.ms)
                                      .fade()
                                      .moveY(begin: 50, end: 0),
                                )
                                    .animate(delay: 2100.ms)
                                    .fade()
                                    .moveY(begin: 50, end: 0),
                              ),
                              horizontalSpaceSmall,
                              InkWell(
                                onTap: () => viewModel
                                    .startquiz(snapshot.data[index]['pin']),
                                child: Container(
                                  padding: const EdgeInsets.all(5),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: getColorWithOpacity(
                                          kcPrimaryColor, 0.2)),
                                  child: Image.asset(
                                    "assets/arrowf.png",
                                    width: screenWidthCustom(context, 0.08),
                                    height: screenWidthCustom(context, 0.08),
                                  )
                                      .animate(delay: 2300.ms)
                                      .fade()
                                      .moveY(begin: 50, end: 0),
                                )
                                    .animate(delay: 2100.ms)
                                    .fade()
                                    .moveY(begin: 50, end: 0),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  );
                },
              );
            } else if (snapshot.hasError) {
              return const Icon(Icons.error_outline);
            } else {
              return displaysimpleprogress(context);
            }
          }),
    );
  }

  @override
  RecomendedquizModel viewModelBuilder(
    BuildContext context,
  ) =>
      RecomendedquizModel();
}
