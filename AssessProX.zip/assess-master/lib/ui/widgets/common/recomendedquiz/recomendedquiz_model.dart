import 'package:assess/services/sharedpref_service.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../../app/app.bottomsheets.dart';
import '../../../../app/app.locator.dart';
import '../../../../app/app.router.dart';
import '../../../views/leaderboard/leaderboard_view.dart';
import '../../../views/solvequiz/solvequiz_view.dart';

class RecomendedquizModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final _bottomService = locator<BottomSheetService>();
  final sharedpref = locator<SharedprefService>();

  void next(Map data) {
    _bottomService.showCustomSheet(variant: BottomSheetType.notice, data: data);
  }

  void startquiz(String pin) {
    _navigationService.navigateWithTransition(
        SolvequizView(
          pin: pin,
        ),
        routeName: Routes.solvequizView,
        transitionStyle: Transition.rightToLeft);
  }

  void leaderboard(String pin) {
    _navigationService.navigateWithTransition(
        LeaderboardView(
          pin: pin,
        ),
        routeName: Routes.leaderboardView,
        transitionStyle: Transition.rightToLeft);
  }
}
