// ignore_for_file: must_be_immutable, depend_on_referenced_packages

import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_colors.dart';
import '../../../common/ui_helpers.dart';
import 'customslider_model.dart';

class Customslider extends StackedView<CustomsliderModel> {
  Customslider({super.key, required this.data, required this.h});
  List data;
  double h;

  @override
  Widget builder(
    BuildContext context,
    CustomsliderModel viewModel,
    Widget? child,
  ) {
    return CarouselSlider(
      options: CarouselOptions(
          height: screenWidthCustom(context, h), autoPlay: true),
      items: data.map((i) {
        return Builder(
          builder: (BuildContext context) {
            return Padding(
                padding: const EdgeInsets.only(bottom: 5),
                child: buildFilePreview(i, context, h));
          },
        );
      }).toList(),
    );
  }

  static Widget buildFilePreview(
      String fileUrl, BuildContext context, double h) {
    String fileType = determineFileType(fileUrl);
    switch (fileType) {
      case 'pdf':
        return SizedBox(
            width: screenWidthCustom(context, h + 0.1),
            height: screenWidthCustom(context, h + 0.1),
            child: const Icon(Icons.picture_as_pdf));
      case 'doc':
      case 'docx':
        return SizedBox(
            width: screenWidthCustom(context, h + 0.1),
            height: screenWidthCustom(context, h + 0.1),
            child: const Icon(Icons.description));
      case 'jpg':
      case 'jpeg':
      case 'png':
        return SizedBox(
            width: screenWidthCustom(context, h + 0.1),
            height: screenWidthCustom(context, h + 0.1),
            child: Image.network(
              fileUrl,
              fit: BoxFit.cover,
            ));
      default:
        return const Icon(
          Icons.error,
          color: kcPrimaryColor,
        );
    }
  }

  static String filename(String url) {
    Uri uri = Uri.parse(url);
    String path = uri.path;
    List<String> parts = path.split('.');
    return "${parts[3]}.${parts.last}";
  }

  static String determineFileType(String fileUrl) {
    Uri uri = Uri.parse(fileUrl);
    String path = uri.path;
    List<String> parts = path.split('.');
    if (parts.isNotEmpty) {
      String extension = parts.last.toLowerCase();
      switch (extension) {
        case 'pdf':
        case 'doc':
        case 'docx':
        case 'jpg':
        case 'jpeg':
        case 'png':
          return extension;
        default:
          return 'unsupported';
      }
    } else {
      return 'unsupported';
    }
  }

  @override
  CustomsliderModel viewModelBuilder(
    BuildContext context,
  ) =>
      CustomsliderModel();
}
