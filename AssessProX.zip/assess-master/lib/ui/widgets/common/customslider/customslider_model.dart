import 'package:stacked/stacked.dart';

class CustomsliderModel extends BaseViewModel {}
