import 'package:assess/ui/common/apihelpers/apihelper.dart';
import 'package:assess/ui/common/uihelper/snakbar_helper.dart';
import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../../app/app.locator.dart';
import '../../../../app/app.router.dart';
import '../../../../services/sharedpref_service.dart';
import '../../../views/innerclass/innerclass_view.dart';

class JoinclassbycodeModel extends BaseViewModel {
  final sharedpref = locator<SharedprefService>();
  final _navigationService = locator<NavigationService>();

  TextEditingController name = TextEditingController();

  Future<void> join(BuildContext context) async {
    if (name.text.isEmpty) {
      show_snackbar(context, "Enter class code");
    } else {
      Map data = await ApiHelper.classjoinbycode(
          name.text, sharedpref.readString("number"), context);
      if (data['status']) {
        Navigator.pop(context);
        innerclass(
            data['a']['_id'],
            data['a']['addedby'] == sharedpref.readString("number")
                ? true
                : false,
            data['a']['title']);
      } else {
        show_snackbar(context, data['message']);
      }
    }
  }

  void innerclass(String id, bool admin, String title) {
    _navigationService.navigateWithTransition(
        InnerclassView(
          id: id,
          admin: admin,
          title: title,
        ),
        routeName: Routes.innerclassView,
        transitionStyle: Transition.rightToLeft);
  }
}
