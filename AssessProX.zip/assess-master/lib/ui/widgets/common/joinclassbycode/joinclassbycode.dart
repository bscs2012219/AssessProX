import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_colors.dart';
import '../../../common/app_strings.dart';
import '../../../common/ui_helpers.dart';
import '../../../common/uihelper/button_helper.dart';
import '../../../common/uihelper/text_helper.dart';
import '../../../common/uihelper/text_veiw_helper.dart';
import 'joinclassbycode_model.dart';

class Joinclassbycode extends StackedView<JoinclassbycodeModel> {
  const Joinclassbycode({super.key});

  @override
  Widget builder(
    BuildContext context,
    JoinclassbycodeModel viewModel,
    Widget? child,
  ) {
    return Container(
      width: screenWidth(context),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: white,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          verticalSpaceSmall,
          text_helper(
              data: "Join Class by code",
              font: poppins,
              color: kcDarkGreyColor,
              size: fontSize18,
              bold: true),
          verticalSpaceSmall,
          text_view_helper(
            hint: "Enter class code",
            controller: viewModel.name,
            showicon: true,
            icon: const Icon(Icons.title),
          ),
          verticalSpaceSmall,
          button_helper(
              onpress: () => viewModel.join(context),
              color: kcPrimaryColor,
              width: screenWidth(context),
              child: text_helper(
                  data: "Join class",
                  font: poppins,
                  color: white,
                  size: fontSize14,
                  bold: true))
        ],
      ),
    );
  }

  @override
  JoinclassbycodeModel viewModelBuilder(
    BuildContext context,
  ) =>
      JoinclassbycodeModel();
}
