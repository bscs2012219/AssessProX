import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/ui_helpers.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_strings.dart';
import '../../../common/uihelper/button_helper.dart';
import '../../../common/uihelper/text_helper.dart';
import '../../../common/uihelper/text_veiw_helper.dart';
import 'newclass_model.dart';

class Newclass extends StackedView<NewclassModel> {
  const Newclass({super.key});

  @override
  Widget builder(
    BuildContext context,
    NewclassModel viewModel,
    Widget? child,
  ) {
    return Container(
      width: screenWidth(context),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: white,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          verticalSpaceSmall,
          text_helper(
              data: "New Class",
              font: poppins,
              color: kcDarkGreyColor,
              size: fontSize18,
              bold: true),
          verticalSpaceSmall,
          text_view_helper(
            hint: "Enter class name",
            controller: viewModel.name,
            showicon: true,
            icon: const Icon(Icons.title),
          ),
          text_view_helper(
            hint: "Enter class Description",
            controller: viewModel.description,
            showicon: true,
            icon: const Icon(Icons.title),
          ),
          verticalSpaceSmall,
          button_helper(
              onpress: () => viewModel.add(context),
              color: kcPrimaryColor,
              width: screenWidth(context),
              child: text_helper(
                  data: "Add class",
                  font: poppins,
                  color: white,
                  size: fontSize14,
                  bold: true))
        ],
      ),
    );
  }

  @override
  NewclassModel viewModelBuilder(
    BuildContext context,
  ) =>
      NewclassModel();
}
