import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';

import '../../../../app/app.locator.dart';
import '../../../../services/sharedpref_service.dart';
import '../../../common/apihelpers/apihelper.dart';
import '../../../common/uihelper/snakbar_helper.dart';

class NewclassModel extends BaseViewModel {
  final sharedpref = locator<SharedprefService>();

  TextEditingController name = TextEditingController();
  TextEditingController description = TextEditingController();

  Future<void> add(BuildContext context) async {
    if (name.text.isEmpty || description.text.isEmpty) {
      show_snackbar(context, "Please fill all fields");
    } else {
      displayprogress(context);
      bool c = await ApiHelper.registerclass(sharedpref.readString('number'),
          name.text, description.text, context);
      hideprogress(context);
      if (c) {
        show_snackbar(context, "class added successfully");
        Navigator.pop(context);
      } else {
        show_snackbar(context, "Something went wrong");
      }
    }
  }
}
