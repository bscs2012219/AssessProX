const String ksHomeBottomSheetTitle = 'Build Great Apps!';
const String ksHomeBottomSheetDescription =
    'Stacked is built to help you build better apps. Give us a chance and we\'ll prove it to you. Check out stacked.filledstacks.com to learn more';

// fonts
const String poppins = 'poppins';
const String roboto = 'roboto';
const String montserrat = 'montserrat';

// icons
const String baseicons = "assets/";

List<String> subjects = [
  "Math",
  "English",
  "Urdu",
  "Science",
  "Physics",
  "Chemistry",
  "Computer",
  "Bio",
  "Arts"
];

const List<String> carouselImages = [
  "https://cdn.elearningindustry.com/wp-content/uploads/2021/10/Shareable-Quizzes-In-Online-Training-7-Reasons.jpg",
  "https://www.riddle.com/imageservice/q_80,f_auto,c_fill,w_960,h_540/ed6cozjawexldjs7yedn",
  "https://altc.alt.ac.uk/blog/wp-content/uploads/sites/1112/2022/08/Blog-Cover-Guidlines-707x409.png"
];
