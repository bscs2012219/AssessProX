// ignore_for_file: depend_on_referenced_packages

import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as path;
import 'package:http/http.dart' as http;
import 'package:firebase_storage/firebase_storage.dart';

import '../../../app/app.locator.dart';
import '../../../services/fire_service.dart';
import 'apihelper.dart';

class FirebaseHelper {
  static Future<String> uploadFile(File? file, String phone) async {
    final fireService = locator<FireService>();

    String filename = path.basename(file!.path);
    String extension = path.extension(file.path);
    String randomChars = DateTime.now().millisecondsSinceEpoch.toString();
    String uniqueFilename = '$filename-$randomChars$extension';

    UploadTask uploadTask = fireService.storage
        .child('user')
        .child(phone)
        .child(uniqueFilename)
        .putFile(file);
    await uploadTask;
    String downloadURL = await fireService.storage
        .child('user')
        .child(phone)
        .child(uniqueFilename)
        .getDownloadURL();
    return downloadURL;
  }

  static Future<void> sendnotificationto(
      String notificationid, String title, String body) async {
    await http.post(Uri.parse('https://fcm.googleapis.com/fcm/send'),
        body: jsonEncode({
          'to': notificationid,
          'priority': 'high',
          'notification': {'title': title, 'body': body}
        }),
        headers: {
          'Content-Type': 'application/json',
          'Authorization':
              'key=AAAA-Ess5oM:APA91bEOYHufd1nXRIGEltAVqlss3qwMy4Iy7XfcSuag_CYw0XupyaIYbd5Ulrewu9oZEJflKHxlWAxXrZHNt_lHZJM1WjE4WOlXWALYP7OeU3_XLX9r33dkQz_rxq13Vb_BuIU83HSP'
        });
  }

  static Future<void> sendallnotification(String title, String des) async {
    List datauser = await ApiHelper.alluser();
    datauser.forEach((element) async {
      FirebaseHelper.sendnotificationto(element['deviceid'], title, des);
    });
  }
}
