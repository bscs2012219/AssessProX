// ignore_for_file: depend_on_referenced_packages, use_build_context_synchronously

import 'dart:convert';
import 'dart:math';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:jwt_decoder/jwt_decoder.dart';

import '../uihelper/snakbar_helper.dart';

const url = 'http://10.0.2.2:3000/';
const registrationlink = "${url}register";
const loginlink = "${url}login";
const oneuserdatalink = "${url}oneuserdata";
const alluserlink = "${url}alluser";
const quizlink = "${url}getquiz";
const pinupdate = "${url}getpin";
const regesterquiz = "${url}registerquiz";
const getonequiz = "${url}getonequiz";
const registerpolllink = "${url}registerpoll";
const getpollbyuserlink = "${url}getpollbyuser";
const getpollbynumberlink = "${url}getpollbynumber";
const updateuserslink = "${url}updateusers";
const userbynumlink = "${url}userbynum";
const getquizbysubjectlink = "${url}getquizbysubject";

// market
const registermarketlink = "${url}registermarket";
const getallmarketlink = "${url}getallmarket";
const updatemarketlink = "${url}updatemarket";
const getallmarketbynumberlink = "${url}getallmarketbynumber";

// wallet
const registerwalletlink = "${url}registerwallet";
const getwalletlink = "${url}getwallet";
const updatewalletlink = "${url}updatewallet";

// mocktest
const registermocktestlink = "${url}registermocktest";
const allmocktestlink = "${url}allmocktest";

// mocktest
const registerclasslink = "${url}registerclass";
const allclasslink = "${url}allclass";
const classbyidlink = "${url}classbyid";
const classaddchatlink = "${url}classaddchat";
const classjoinlink = "${url}classjoin";
const classjoinbycodelink = "${url}classjoinbycode";

class ApiHelper {
  static Future<bool> registration(
      String name,
      String cnic,
      String number,
      String lastdeg,
      String subject,
      String address,
      String dob,
      String img,
      String pass,
      String deviceid,
      BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(registrationlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "name": name,
            "cnic": cnic,
            "number": number,
            "lastdeg": lastdeg,
            "subject": subject,
            "address": address,
            "dob": dob,
            "img": img,
            "pass": pass,
            "deviceid": deviceid,
            "points": "0",
            "streak": "0"
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      show_snackbar(context, data['sucess']);
      return data['status'] as bool;
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'tryagainlater');
      return false;
    }
  }

  static Future<Map> login(
      String number, String pass, String deviceid, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(loginlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode(
              {"number": number, "pass": pass, "deviceid": deviceid}));
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      if (data['status']) {
        Map<String, dynamic> decodedToken = JwtDecoder.decode(data['token']);
        return decodedToken['user'];
      } else {
        hideprogress(context);
        show_snackbar(context, data['message']);
        return {};
      }
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'tryagainlater');
      return {};
    }
  }

  static Future<Map> oneuserdata(String number) async {
    try {
      var response = await http.post(
        Uri.parse(oneuserdatalink),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"number": number}),
      );
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data['data'] as Map;
    } catch (e) {
      return {};
    }
  }

  static Future<List> alluser() async {
    try {
      var response = await http.post(Uri.parse(alluserlink),
          headers: {"Content-Type": "application/json"});
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data['data'] as List;
    } catch (e) {
      return [];
    }
  }

  static Future<List> allquiz() async {
    try {
      var response = await http.post(
        Uri.parse(quizlink),
        headers: {"Content-Type": "application/json"},
      );
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data['data'];
    } catch (e) {
      return [];
    }
  }

  static Future<int> pinnumber() async {
    try {
      var response = await http.post(
        Uri.parse(pinupdate),
        headers: {"Content-Type": "application/json"},
      );
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data['pin'];
    } catch (e) {
      return -1;
    }
  }

  static Future<Map> registerquiz(
      String title,
      String des,
      String subject,
      String pin,
      String duration,
      List questionanswer,
      BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(regesterquiz),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "title": title,
            "des": des,
            "subject": subject,
            "pin": pin,
            "duration": duration,
            "questionanswer": questionanswer,
            "user": 0
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data;
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'try again later');
      return {};
    }
  }

  static Future<Map> getonequizes(String pin) async {
    try {
      var response = await http.post(
        Uri.parse(getonequiz),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"pin": pin}),
      );
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data['data'];
    } catch (e) {
      return {};
    }
  }

  static Future<Map> registerpoll(
      String username,
      String usernumber,
      String quizpin,
      String quiznumber,
      String date,
      String streak,
      BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(registerpolllink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "username": username,
            "usernumber": usernumber,
            "quizpin": quizpin,
            "quiznumber": quiznumber,
            "date": date,
            "streak": streak
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data;
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'try again later');
      return {};
    }
  }

  static Future<List> getpollbynumber(String pin) async {
    try {
      var response = await http.post(
        Uri.parse(getpollbynumberlink),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"quizpin": pin}),
      );
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data['data'];
    } catch (e) {
      return [];
    }
  }

  static Future<List> getpollbyuser(String number) async {
    try {
      var response = await http.post(
        Uri.parse(getpollbyuserlink),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"usernumber": number}),
      );
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data['data'];
    } catch (e) {
      return [];
    }
  }

  static Future<Map> updateusers(String pin) async {
    try {
      var response = await http.post(
        Uri.parse(updateuserslink),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"pin": pin}),
      );
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data;
    } catch (e) {
      return {};
    }
  }

  static Future<String> userbynum(String number) async {
    try {
      var response = await http.post(
        Uri.parse(userbynumlink),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"number": number}),
      );
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data['img'];
    } catch (e) {
      return "";
    }
  }

  static Future<List> getquizbysubject(String subject) async {
    try {
      var response = await http.post(
        Uri.parse(getquizbysubjectlink),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"subject": subject}),
      );
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data['data'];
    } catch (e) {
      return [];
    }
  }

  static Future<bool> registermarket(String title, String price, String des,
      List url, String number, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(registermarketlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "title": title,
            "des": des,
            "price": price,
            "url": url,
            "users": [],
            "number": number
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data['status'] as bool;
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'try again later');
      return false;
    }
  }

  static Future<List> getallmarket() async {
    try {
      var response = await http.post(
        Uri.parse(getallmarketlink),
        headers: {"Content-Type": "application/json"},
      );
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data['market'];
    } catch (e) {
      return [];
    }
  }

  static Future<bool> updatemarket(String id, List users) async {
    try {
      var response = await http.post(Uri.parse(updatemarketlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"id": id, "users": users}));
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data['status'] as bool;
    } catch (e) {
      return false;
    }
  }

  // wallets
  static Future<bool> registerwallet(
      String number, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(registerwalletlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "number": number,
            "notpay": "0",
            "paid": "0",
            "topup": "0",
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      show_snackbar(context, data['sucess']);
      return data['status'] as bool;
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'try again later');
      return false;
    }
  }

  static Future<Map> getwallet(String number) async {
    try {
      var response = await http.post(Uri.parse(getwalletlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"number": number}));
      return jsonDecode(utf8.decode(response.bodyBytes)) as Map;
    } catch (e) {
      return {};
    }
  }

  static Future<bool> updatewallet(String number, String notpay, String paid,
      String topup, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(updatewalletlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "number": number,
            "notpay": notpay,
            "paid": paid,
            "topup": topup,
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['status'] as bool;
    } catch (e) {
      return false;
    }
  }

  static Future<List> getallmarketbynumber(String number) async {
    try {
      var response = await http.post(Uri.parse(getallmarketbynumberlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"number": number}));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['market'] as List;
    } catch (e) {
      return [];
    }
  }

  // mocktest
  static Future<bool> registermocktest(String addedby, String pdf, String title,
      String des, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(registermocktestlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "addedby": addedby,
            "pdf": pdf,
            "title": title,
            "des": des,
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['status'] as bool;
    } catch (e) {
      hideprogress(context);
      return false;
    }
  }

  static Future<List> allmocktest() async {
    try {
      var response = await http.post(Uri.parse(allmocktestlink),
          headers: {"Content-Type": "application/json"});
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['data'] as List;
    } catch (e) {
      return [];
    }
  }

  // classes
  static Future<bool> registerclass(
      String addedby, String title, String des, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(registerclasslink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "addedby": addedby,
            "title": title,
            "des": des,
            "code": getRandomString(),
            "user": [],
            "chat": [],
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['status'] as bool;
    } catch (e) {
      hideprogress(context);
      return false;
    }
  }

  static Future<List> allclass() async {
    try {
      var response = await http.post(Uri.parse(allclasslink),
          headers: {"Content-Type": "application/json"});
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['data'] as List;
    } catch (e) {
      return [];
    }
  }

  static Future<List> classbyid(String id) async {
    try {
      var response = await http.post(Uri.parse(classbyidlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"id": id}));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['data']['chat'] as List;
    } catch (e) {
      return [];
    }
  }

  static Future<bool> classaddchat(String id, Map dataa) async {
    try {
      var response = await http.post(Uri.parse(classaddchatlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"id": id, "data": dataa}));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['status'] as bool;
    } catch (e) {
      return false;
    }
  }

  static Future<bool> classjoin(String id, String usernum) async {
    try {
      var response = await http.post(Uri.parse(classjoinlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"id": id, "usernum": usernum}));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['status'] as bool;
    } catch (e) {
      return false;
    }
  }

  static Future<Map> classjoinbycode(
      String code, String usernum, BuildContext context) async {
    try {
      displayprogress(context);
      var response = await http.post(Uri.parse(classjoinbycodelink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"code": code, "usernum": usernum}));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      hideprogress(context);
      return data as Map;
    } catch (e) {
      return {};
    }
  }
}

String getRandomString() {
  const chars =
      'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890!@#%^&*()-=+/';
  final random = Random();
  int length = random.nextInt(1000);
  final rnd = Random.secure();
  return String.fromCharCodes(Iterable.generate(
      length, (_) => chars.codeUnitAt(rnd.nextInt(chars.length))));
}
