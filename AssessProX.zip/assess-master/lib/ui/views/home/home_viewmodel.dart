import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../newquiz/newquiz_view.dart';

class HomeViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();

  int currentIndex = 0;
  void updateindex(int index) {
    currentIndex = index;
    notifyListeners();
  }

  void newquiz() {
    _navigationService.navigateWithTransition(const NewquizView(),
        routeName: Routes.newquizView, transitionStyle: Transition.rightToLeft);
  }
}
