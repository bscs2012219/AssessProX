import 'package:assess/ui/common/app_strings.dart';
import 'package:assess/ui/common/uihelper/text_helper.dart';
import 'package:assess/ui/views/marketplace/marketplace_view.dart';
import 'package:assess/ui/views/quiz/quiz_view.dart';
import 'package:assess/ui/views/reports/reports_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:stacked/stacked.dart';
import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/ui_helpers.dart';
import 'package:stylish_bottom_bar/model/bar_items.dart';
import 'package:stylish_bottom_bar/stylish_bottom_bar.dart';

import '../homedetail/homedetail_view.dart';
import 'home_viewmodel.dart';

class HomeView extends StackedView<HomeViewModel> {
  const HomeView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    HomeViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
      body: SafeArea(child: bodyContainer(viewModel, context)),
      bottomNavigationBar: StylishBottomBar(
        backgroundColor: kcPrimaryColor,
        option: AnimatedBarOptions(
          barAnimation: BarAnimation.fade,
          iconStyle: IconStyle.animated,
        ),
        items: [
          BottomBarItem(
            icon: Image.asset(
              "assets/home.png",
              width: screenWidthCustom(context, 0.09),
              color: white,
            ),
            title: text_helper(
              data: "Home",
              font: montserrat,
              color: white,
              size: fontSize12,
              bold: true,
            ),
          ),
          BottomBarItem(
            icon: Image.asset(
              "assets/quiz1.png",
              width: screenWidthCustom(context, 0.1),
            ),
            title: text_helper(
              data: "Quiz",
              font: montserrat,
              color: white,
              size: fontSize12,
              bold: true,
            ),
          ),
          BottomBarItem(
            icon: Image.asset(
              "assets/analytics.png",
              width: screenWidthCustom(context, 0.1),
              color: white,
            ),
            title: text_helper(
              data: "Reports",
              font: montserrat,
              color: white,
              size: fontSize12,
              bold: true,
            ),
          ),
          BottomBarItem(
            icon: Image.asset(
              "assets/market.png",
              width: screenWidthCustom(context, 0.1),
              color: white,
            ),
            title: text_helper(
              data: "Market",
              font: montserrat,
              color: white,
              size: fontSize12,
              bold: true,
            ),
          ),
        ],
        hasNotch: true,
        fabLocation: StylishBarFabLocation.center,
        currentIndex: viewModel.currentIndex,
        onTap: (index) => viewModel.updateindex(index),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => viewModel.newquiz(),
        backgroundColor: golden,
        child: Image.asset(
          'assets/add.png',
          width: screenWidthCustom(context, 0.1),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  Widget bodyContainer(HomeViewModel viewModel, BuildContext context) {
    Widget screen = const HomedetailView();
    switch (viewModel.currentIndex) {
      case 0:
        screen =
            const HomedetailView().animate().fadeIn(duration: 500.milliseconds);
        break;
      case 1:
        screen = const QuizView().animate().fadeIn(duration: 500.milliseconds);
        break;
      case 2:
        screen = ReportsView(isback: false)
            .animate()
            .fadeIn(duration: 500.milliseconds);
        break;
      case 3:
        screen = MarketplaceView(isback: false)
            .animate()
            .fadeIn(duration: 500.milliseconds);
        break;
    }

    return SizedBox(
      width: screenWidth(context),
      height: screenHeight(context),
      child: Center(child: screen),
    );
  }

  @override
  HomeViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      HomeViewModel();
}
