import 'package:assess/ui/common/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:lottie/lottie.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_strings.dart';
import '../../common/ui_helpers.dart';
import '../../common/uihelper/button_helper.dart';
import '../../common/uihelper/text_helper.dart';
import '../../common/uihelper/text_veiw_helper.dart';
import 'signup_viewmodel.dart';

class SignupView extends StackedView<SignupViewModel> {
  const SignupView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    SignupViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        appBar: AppBar(
            backgroundColor: golden,
            iconTheme: const IconThemeData(color: kcDarkGreyColor),
            title: text_helper(
              data: "Signup",
              font: poppins,
              size: fontSize18,
              bold: true,
              color: kcDarkGreyColor,
            )),
        backgroundColor: white,
        body: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Lottie.asset(
                  'assets/login.json',
                  width: screenWidthCustom(context, 0.8),
                  height: screenWidthCustom(context, 0.6),
                ),
                text_view_helper(
                  hint: "Enter name",
                  controller: viewModel.name,
                  formatter: [
                    FilteringTextInputFormatter.allow(getRegExpstring())
                  ],
                  showicon: true,
                )
                    .animate(delay: 700.milliseconds)
                    .fade()
                    .moveY(begin: 50, end: 0),
                text_view_helper(
                  hint: "Enter number",
                  controller: viewModel.number,
                  showicon: true,
                  formatter: [
                    FilteringTextInputFormatter.allow(getRegExpint())
                  ],
                  icon: const Icon(Icons.call),
                  maxlength: 11,
                  textInputType: TextInputType.phone,
                )
                    .animate(delay: 900.milliseconds)
                    .fade()
                    .moveY(begin: 50, end: 0),
                text_view_helper(
                  hint: "Enter cnic",
                  controller: viewModel.cnic,
                  showicon: true,
                  icon: const Icon(Icons.dock),
                  maxlength: 13,
                  textInputType: TextInputType.phone,
                  formatter: [
                    FilteringTextInputFormatter.allow(getRegExpint())
                  ],
                )
                    .animate(delay: 1100.milliseconds)
                    .fade()
                    .moveY(begin: 50, end: 0),
                text_view_helper(
                        hint: "Enter address",
                        controller: viewModel.address,
                        showicon: true,
                        icon: const Icon(Icons.home))
                    .animate(delay: 1300.milliseconds)
                    .fade()
                    .moveY(begin: 50, end: 0),
                InkWell(
                  onTap: () => viewModel.selectdob(context),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: text_helper(
                        data: viewModel.dob.text == ''
                            ? "Select Date of Birth"
                            : viewModel.dob.text,
                        font: poppins,
                        color: kcDarkGreyColor,
                        size: fontSize14),
                  ),
                )
                    .animate(delay: 1500.milliseconds)
                    .fade()
                    .moveY(begin: 50, end: 0),
                button_helper(
                        onpress: () => viewModel.next(context),
                        color: kcPrimaryColor,
                        width: screenWidthCustom(context, 0.4),
                        child: text_helper(
                            data: "next",
                            font: poppins,
                            bold: true,
                            color: white,
                            size: fontSize14))
                    .animate(delay: 1700.milliseconds)
                    .fade()
                    .moveY(begin: 50, end: 0),
                verticalSpaceLarge,
              ],
            ),
          ),
        ));
  }

  @override
  SignupViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      SignupViewModel();
}
