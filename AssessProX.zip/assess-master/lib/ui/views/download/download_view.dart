// ignore_for_file: must_be_immutable

import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/app_strings.dart';
import 'package:assess/ui/common/ui_helpers.dart';
import 'package:assess/ui/common/uihelper/text_helper.dart';
import 'package:assess/ui/widgets/common/customslider/customslider.dart';
import 'package:assess/ui/widgets/common/top/top.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import 'download_viewmodel.dart';

class DownloadView extends StackedView<DownloadViewModel> {
  DownloadView({Key? key, required this.url}) : super(key: key);
  List url;

  @override
  Widget builder(
    BuildContext context,
    DownloadViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: Column(
            children: [
              Top(title: "Download"),
              Column(
                children: url
                    .map((e) => InkWell(
                          onTap: () => viewModel.downloadFile(
                              e, Customslider.filename(e), context),
                          child: Container(
                            width: screenWidth(context),
                            padding: const EdgeInsets.all(10),
                            margin: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: getColorWithOpacity(kcLightGrey, 0.1)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Customslider.buildFilePreview(e, context, 0.02),
                                text_helper(
                                    data: Customslider.filename(e),
                                    font: poppins,
                                    color: kcPrimaryColor,
                                    size: fontSize14),
                                const Icon(
                                  Icons.download,
                                  color: kcPrimaryColor,
                                )
                              ],
                            ),
                          ),
                        ))
                    .toList(),
              )
            ],
          ),
        ));
  }

  @override
  void onViewModelReady(DownloadViewModel viewModel) => viewModel.first();

  @override
  DownloadViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      DownloadViewModel();
}
