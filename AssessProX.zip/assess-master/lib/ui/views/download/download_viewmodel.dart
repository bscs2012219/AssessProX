// ignore_for_file: depend_on_referenced_packages, use_build_context_synchronously

import 'package:permission_handler/permission_handler.dart';
import 'package:assess/ui/common/uihelper/snakbar_helper.dart';
import 'package:flutter/cupertino.dart';
import 'package:background_downloader/background_downloader.dart';
import 'package:stacked/stacked.dart';

class DownloadViewModel extends BaseViewModel {
  void first() {
    per();
  }

  Future<bool> per() async {
    var status = await Permission.storage.request();
    if (status.isDenied) {
      return false;
    } else {
      return true;
    }
  }

  Future<void> downloadFile(
      String url, String fileName, BuildContext context) async {
    final task = DownloadTask(
        url: url,
        filename: fileName,
        directory: 'file',
        updates: Updates.statusAndProgress,
        requiresWiFi: true,
        retries: 5,
        allowPause: false,
        metaData: 'data for me');
    final result = await FileDownloader().download(task);
    switch (result.status) {
      case TaskStatus.complete:
        show_snackbar(context, 'success');
      case TaskStatus.canceled:
        show_snackbar(context, 'Download was canceled');
      case TaskStatus.paused:
        show_snackbar(context, 'Download was paused');
      default:
        show_snackbar(context, 'Download not successful');
    }
  }
}
