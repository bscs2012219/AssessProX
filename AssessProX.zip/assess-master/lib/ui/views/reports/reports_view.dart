import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import '../../common/apihelpers/apihelper.dart';
import '../../common/app_colors.dart';
import '../../common/app_strings.dart';
import '../../common/ui_helpers.dart';
import '../../common/uihelper/snakbar_helper.dart';
import '../../common/uihelper/text_helper.dart';
import '../../widgets/common/top/top.dart';
import '../wallet/wallet_viewmodel.dart';
import 'reports_viewmodel.dart';

class ReportsView extends StackedView<ReportsViewModel> {
  ReportsView({Key? key, this.isback = true}) : super(key: key);
  bool isback;

  @override
  Widget builder(
    BuildContext context,
    ReportsViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: Theme.of(context).colorScheme.background,
        body: SafeArea(
          child: Column(
            children: [
              Top(title: "Reports", isback: isback),
              Expanded(
                child: FutureBuilder(
                  future: ApiHelper.getpollbyuser(
                      viewModel.sharedpref.readString('number')),
                  builder: (BuildContext context, AsyncSnapshot snapshot) {
                    if (snapshot.hasData) {
                      return Column(
                        children: [
                          givechart(() => chartdataret(snapshot.data)),
                          Expanded(
                            child: ListView.builder(
                              itemCount: snapshot.data.length,
                              itemBuilder: (BuildContext context, int index) {
                                return Container(
                                  width: screenWidth(context),
                                  padding: const EdgeInsets.all(10),
                                  margin: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: getColorWithOpacity(
                                          kcLightGrey, 0.1)),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      text_helper(
                                        data: snapshot.data[index]['date'],
                                        font: poppins,
                                        color: kcDarkGreyColor,
                                        size: fontSize14,
                                        bold: true,
                                      ),
                                      FutureBuilder(
                                        future: ApiHelper.getonequizes(
                                            snapshot.data[index]['quizpin']),
                                        builder: (BuildContext context,
                                            AsyncSnapshot<Map<dynamic, dynamic>>
                                                snapshot2) {
                                          if (snapshot2.hasData) {
                                            return Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                text_helper(
                                                  data:
                                                      snapshot2.data!['title'],
                                                  font: poppins,
                                                  color: kcPrimaryColor,
                                                  size: fontSize14,
                                                  bold: true,
                                                ),
                                                text_helper(
                                                  data: snapshot2.data!['des'],
                                                  font: poppins,
                                                  color: kcLightGrey,
                                                  size: fontSize12,
                                                  bold: true,
                                                ),
                                              ],
                                            );
                                          } else if (snapshot2.hasError) {
                                            return const Icon(
                                              Icons.error,
                                              color: kcDarkGreyColor,
                                            );
                                          } else {
                                            return displaysimpleprogress(
                                                context);
                                          }
                                        },
                                      ),
                                      text_helper(
                                        data: "My Numbers : " +
                                            snapshot.data[index]['quiznumber'],
                                        font: poppins,
                                        color: kcPrimaryColor,
                                        size: fontSize14,
                                        bold: true,
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      );
                    } else if (snapshot.hasError) {
                      return const Icon(
                        Icons.error,
                        color: kcDarkGreyColor,
                      );
                    } else {
                      return displaysimpleprogress(context);
                    }
                  },
                ),
              )
            ],
          ),
        ));
  }

  Widget givechart(Function function,
      {String name = 'Day wise quiz solved report'}) {
    return FutureBuilder(
      future: function(),
      builder: (BuildContext context, AsyncSnapshot snapshot2) {
        if (snapshot2.hasData) {
          return SfCartesianChart(
              primaryXAxis: CategoryAxis(),
              primaryYAxis: NumericAxis(
                  minimum: 0, maximum: snapshot2.data['max'], interval: 1),
              tooltipBehavior: TooltipBehavior(enable: true),
              legend: const Legend(
                  isVisible: true, position: LegendPosition.bottom),
              series: <ColumnSeries<ChartData, String>>[
                ColumnSeries<ChartData, String>(
                    dataSource: snapshot2.data['data'],
                    xValueMapper: (ChartData data, _) => data.x,
                    yValueMapper: (ChartData data, _) => data.y,
                    name: name,
                    color: kcPrimaryColor)
              ]);
        } else if (snapshot2.hasError) {
          return const Icon(
            Icons.error,
            color: kcDarkGreyColor,
          );
        } else {
          return displaysimpleprogress(context);
        }
      },
    );
  }

  Future<Map> chartdataret(List d) async {
    List<ChartData> data = [];
    Map tem = {};
    for (var element in d) {
      if (tem.containsKey(element['date'])) {
        tem[element['date']] = tem[element['date']]! + 1.0;
      } else {
        tem[element['date']] = 1.0;
      }
    }
    tem.forEach((key, value) {
      data.add(ChartData(key, value));
    });
    data.sort((a, b) => b.x.compareTo(a.x));
    if (data.length > 7) {
      data = data.sublist(0, 7);
    }
    double max = 0;
    for (var element in data) {
      if (element.y > max) {
        max = element.y;
      }
    }
    return {"data": data, "max": max};
  }

  @override
  ReportsViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      ReportsViewModel();
}
