// ignore_for_file: use_build_context_synchronously

import 'dart:io';

import 'package:assess/ui/common/apihelpers/apihelper.dart';
import 'package:assess/ui/common/apihelpers/firebsaeuploadhelper.dart';
import 'package:assess/ui/common/uihelper/snakbar_helper.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../services/sharedpref_service.dart';

class MarketplaceaddgoodsViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final _sharedpref = locator<SharedprefService>();

  TextEditingController price = TextEditingController();
  TextEditingController name = TextEditingController();
  TextEditingController des = TextEditingController();

  Future<void> add(BuildContext context) async {
    if (price.text.isEmpty || name.text.isEmpty || des.text.isEmpty) {
      show_snackbar(context, "Enter all things");
    } else if (selectedFiles.isEmpty) {
      show_snackbar(context, "Select a file to continue");
    } else {
      displayprogress(context);
      List<String> urls = [];
      for (var element in selectedFiles) {
        String u = await FirebaseHelper.uploadFile(
            File(element.path!), _sharedpref.readString('number'));
        urls.add(u);
      }
      bool c = await ApiHelper.registermarket(name.text, price.text, des.text,
          urls, _sharedpref.readString('number'), context);
      if (c) {
        await FirebaseHelper.sendallnotification(
            "New Product", "Let's check it out");
        hideprogress(context);
        show_snackbar(context, "added");
        _navigationService.back();
      } else {
        show_snackbar(context, "try again later");
      }
    }
  }

  List<PlatformFile> selectedFiles = [];

  void pickFiles() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'],
    );

    if (result != null) {
      PlatformFile file = result.files.first;
      selectedFiles.add(file);
      notifyListeners();
    }
  }

  void removeFileFromList(PlatformFile file) {
    selectedFiles.remove(file);
    notifyListeners();
  }
}
