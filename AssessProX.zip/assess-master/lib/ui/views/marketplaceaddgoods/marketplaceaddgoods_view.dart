import 'dart:io';

import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/app_strings.dart';
import 'package:assess/ui/common/ui_helpers.dart';
import 'package:assess/ui/common/uihelper/button_helper.dart';
import 'package:assess/ui/common/uihelper/text_helper.dart';
import 'package:assess/ui/common/uihelper/text_veiw_helper.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:stacked/stacked.dart';

import '../../widgets/common/top/top.dart';
import 'marketplaceaddgoods_viewmodel.dart';

class MarketplaceaddgoodsView
    extends StackedView<MarketplaceaddgoodsViewModel> {
  const MarketplaceaddgoodsView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    MarketplaceaddgoodsViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: ListView(
            children: [
              Top(title: "Sell Products"),
              button_helper(
                  onpress: () => viewModel.pickFiles(),
                  color: kcPrimaryColor,
                  width: screenWidth(context),
                  child: text_helper(
                      data: "Add file",
                      font: poppins,
                      color: white,
                      size: fontSize14)),
              Column(
                children: viewModel.selectedFiles
                    .map((e) => Container(
                          width: screenWidth(context),
                          padding: const EdgeInsets.all(10),
                          margin: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: getColorWithOpacity(kcLightGrey, 0.1)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              getFilePreview(e, context),
                              text_helper(
                                  data: e.name,
                                  font: poppins,
                                  bold: true,
                                  color: kcPrimaryColor,
                                  size: fontSize14),
                              InkWell(
                                  onTap: () => viewModel.removeFileFromList(e),
                                  child: const Icon(
                                    Icons.delete,
                                    color: Colors.red,
                                  ))
                            ],
                          ),
                        ))
                    .toList(),
              ),
              text_view_helper(
                  showicon: true,
                  hint: "Enter Name",
                  controller: viewModel.name),
              Container(
                width: screenHeightCustom(context, 1),
                margin: EdgeInsets.all(5),
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                      offset: const Offset(2, 2),
                      blurRadius: 1,
                      spreadRadius: 1,
                      color: getColorWithOpacity(kcPrimaryColorDark, 0.2))
                ], borderRadius: BorderRadius.circular(10), color: white),
                child: TextFormField(
                  controller: viewModel.price,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    counterText: "",
                    hintStyle: text_helper.customstyle(
                        poppins, kcDarkGreyColor, fontSize14, context, false),
                    hintText: "Enter Price",
                    prefixIcon: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        text_helper(
                          data: "Rs",
                          font: poppins,
                          color: kcDarkGreyColor,
                          size: fontSize14,
                          bold: true,
                        ),
                      ],
                    ),
                  ),
                  style: text_helper.customstyle(
                      poppins, kcDarkGreyColor, fontSize14, context, false),
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(getRegExpint())
                  ],
                ),
              ),
              text_view_helper(
                  showicon: true,
                  icon: const Icon(Icons.description),
                  maxline: null,
                  hint: "Enter Description",
                  controller: viewModel.des),
              button_helper(
                  onpress: () => viewModel.add(context),
                  color: kcPrimaryColorDark,
                  width: screenWidthCustom(context, 0.5),
                  child: text_helper(
                      data: "Add",
                      font: poppins,
                      color: white,
                      size: fontSize14))
            ],
          ),
        ));
  }

  Widget getFilePreview(PlatformFile file, BuildContext context) {
    String extension = file.extension ?? "";

    if (["jpg", "jpeg", "png"].contains(extension)) {
      return SizedBox(
          width: screenWidthCustom(context, 0.1),
          height: screenWidthCustom(context, 0.1),
          child: Image.file(File(file.path!)));
    } else {
      return getDocumentIcon(extension);
    }
  }

  Widget getDocumentIcon(String extension) {
    IconData iconData;
    switch (extension) {
      case "pdf":
        iconData = Icons.picture_as_pdf;
        break;
      case "doc":
      case "docx":
        iconData = Icons.description;
        break;
      default:
        iconData = Icons.insert_drive_file;
    }
    return Icon(iconData);
  }

  @override
  MarketplaceaddgoodsViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      MarketplaceaddgoodsViewModel();
}
