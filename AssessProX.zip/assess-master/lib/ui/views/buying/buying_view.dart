// ignore_for_file: must_be_immutable, prefer_interpolation_to_compose_strings

import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/app_strings.dart';
import 'package:assess/ui/common/ui_helpers.dart';
import 'package:assess/ui/common/uihelper/button_helper.dart';
import 'package:assess/ui/common/uihelper/text_helper.dart';
import 'package:assess/ui/widgets/common/customslider/customslider.dart';
import 'package:assess/ui/widgets/common/top/top.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import 'buying_viewmodel.dart';

class BuyingView extends StackedView<BuyingViewModel> {
  BuyingView({Key? key, required this.data}) : super(key: key);
  Map data;

  @override
  Widget builder(
    BuildContext context,
    BuyingViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Top(title: "Buy Goods"),
                verticalSpaceSmall,
                Customslider(data: data['url'], h: 0.2),
                text_helper(
                  data: data['title'],
                  font: poppins,
                  color: kcPrimaryColor,
                  size: fontSize16,
                  bold: true,
                ),
                text_helper(
                  data: "\$" + data['price'],
                  font: poppins,
                  color: kcPrimaryColor,
                  size: fontSize14,
                  bold: true,
                ),
                text_helper(
                  data: data['des'],
                  font: poppins,
                  color: kcLightGrey,
                  textAlign: TextAlign.start,
                  size: fontSize12,
                  bold: true,
                ),
                List.of(data['users'])
                        .contains(viewModel.sharedpref.readString('number'))
                    ? button_helper(
                        onpress: () => viewModel.download(data['url']),
                        color: kcPrimaryColor,
                        width: screenWidth(context),
                        child: text_helper(
                            data: "Downlaod",
                            font: poppins,
                            color: white,
                            size: fontSize14))
                    : button_helper(
                        onpress: () => viewModel.buy(context, data),
                        color: kcPrimaryColor,
                        width: screenWidth(context),
                        child: text_helper(
                            data: "Buy",
                            font: poppins,
                            color: white,
                            size: fontSize14))
              ],
            ),
          ),
        ));
  }

  @override
  BuyingViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      BuyingViewModel();
}
