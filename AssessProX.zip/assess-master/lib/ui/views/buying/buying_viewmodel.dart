// ignore_for_file: use_build_context_synchronously

import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../services/sharedpref_service.dart';
import '../../common/apihelpers/apihelper.dart';
import '../../common/uihelper/snakbar_helper.dart';
import '../download/download_view.dart';

class BuyingViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final sharedpref = locator<SharedprefService>();

  Future<void> buy(BuildContext context, Map data) async {
    displayprogress(context);
    Map wdata = await ApiHelper.getwallet(sharedpref.readString('number'));
    if (wdata['status']) {
      Map rdata = await ApiHelper.getwallet(data['number']);
      bool ru = await ApiHelper.updatewallet(
          data['number'],
          rdata['rest']['notpay'],
          rdata['rest']['paid'],
          "${int.parse(rdata['rest']['topup']) + int.parse(data['price'])}",
          context);
      if (ru) {
        wdata = await ApiHelper.getwallet(sharedpref.readString('number'));
        bool uw = await ApiHelper.updatewallet(
            sharedpref.readString('number'),
            wdata['rest']['notpay'],
            "${int.parse(wdata['rest']['paid']) + int.parse(data['price'])}",
            wdata['rest']['topup'],
            context);
        if (uw) {
          List us = List.of(data['users']);
          us.add(sharedpref.readString('number'));
          bool result = await ApiHelper.updatemarket(data['_id'], us);
          if (result) {
            hideprogress(context);
            _navigationService.back();
            _navigationService.back();
          }
        }
      }
    }
  }

  void download(Map data) {
    _navigationService.replaceWithTransition(
        DownloadView(
          url: data['url'],
        ),
        routeName: Routes.downloadView,
        transitionStyle: Transition.rightToLeft);
  }
}
