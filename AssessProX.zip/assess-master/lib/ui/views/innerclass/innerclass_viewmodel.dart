import 'dart:io';

import 'package:assess/ui/common/apihelpers/apihelper.dart';
import 'package:assess/ui/common/apihelpers/firebsaeuploadhelper.dart';
import 'package:assess/ui/common/uihelper/snakbar_helper.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:image_picker/image_picker.dart';
import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../services/sharedpref_service.dart';

class InnerclassViewModel extends BaseViewModel {
  final sharedpref = locator<SharedprefService>();

  TextEditingController text = TextEditingController();

  Future<void> pickPdfFile(String id, BuildContext context) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );

    if (result != null) {
      File selectedFile = File(result.files.single.path!);
      await upload(id, context, selectedFile, "pdf");
      notifyListeners();
    }
  }

  Future<void> pic(String id, BuildContext context) async {
    final pickedFile =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      File image = File(pickedFile.path);
      await upload(id, context, image, "img");
      notifyListeners();
    }
  }

  Future<void> upload(
      String id, BuildContext context, File file, String type) async {
    displayprogress(context);
    String urll =
        await FirebaseHelper.uploadFile(file, sharedpref.readString("number"));
    Map d = {"data": urll, "type": type, "time": DateTime.now().toString()};
    bool c = await ApiHelper.classaddchat(id, d);
    hideprogress(context);
    if (c) {
      show_snackbar(context, "Uploaded");
    } else {
      show_snackbar(context, "Failed");
    }
  }

  Future<void> send(String id, BuildContext context) async {
    if (text.text.isNotEmpty) {
      displayprogress(context);
      Map d = {
        "data": text.text,
        "type": "txt",
        "time": DateTime.now().toString()
      };
      bool c = await ApiHelper.classaddchat(id, d);
      hideprogress(context);
      text.clear();
      notifyListeners();
      if (c) {
        show_snackbar(context, "Uploaded");
      } else {
        show_snackbar(context, "Failed");
      }
    }
  }
}
