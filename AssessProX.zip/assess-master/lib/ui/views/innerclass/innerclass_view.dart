import 'package:assess/ui/common/apihelpers/apihelper.dart';
import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/uihelper/text_veiw_helper.dart';
import 'package:assess/ui/views/mocktest/showpdf.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_strings.dart';
import '../../common/ui_helpers.dart';
import '../../common/uihelper/snakbar_helper.dart';
import '../../common/uihelper/text_helper.dart';
import '../../widgets/common/top/top.dart';
import 'innerclass_viewmodel.dart';

class InnerclassView extends StackedView<InnerclassViewModel> {
  InnerclassView(
      {Key? key, required this.id, required this.admin, required this.title})
      : super(key: key);
  String id, title;
  bool admin;

  @override
  Widget builder(
    BuildContext context,
    InnerclassViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: Column(
            children: [
              Top(
                title: title,
              ),
              Expanded(
                child: FutureBuilder(
                  future: ApiHelper.classbyid(id),
                  builder: (BuildContext context, AsyncSnapshot snapshot) {
                    if (snapshot.hasData) {
                      if (snapshot.data.toString() == '[]') {
                        return Center(
                          child: text_helper(
                              data: "No Data",
                              font: poppins,
                              color: kcDarkGreyColor,
                              size: fontSize14),
                        );
                      } else {
                        return ListView.builder(
                          itemCount: snapshot.data.length,
                          reverse: true,
                          itemBuilder: (BuildContext context, int index) {
                            return Container(
                              padding: const EdgeInsets.all(10),
                              margin: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: getColorWithOpacity(golden, 0.1),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  snapshot.data[index]['type'] == 'txt'
                                      ? text_helper(
                                          data: snapshot.data[index]['data'],
                                          font: poppins,
                                          color: kcDarkGreyColor,
                                          size: fontSize14,
                                          bold: true)
                                      : snapshot.data[index]['type'] == 'img'
                                          ? CachedNetworkImage(
                                              imageUrl: snapshot.data[index]
                                                  ['data'],
                                              imageBuilder:
                                                  (context, imageProvider) =>
                                                      ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                                child: Container(
                                                  width: screenWidth(context),
                                                  height: 250,
                                                  decoration: BoxDecoration(
                                                    image: DecorationImage(
                                                      image: imageProvider,
                                                      fit: BoxFit.cover,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              placeholder: (context, url) =>
                                                  displaysimpleprogress(
                                                      context),
                                              errorWidget:
                                                  (context, url, error) =>
                                                      const Icon(
                                                Icons.error,
                                                color: kcDarkGreyColor,
                                              ),
                                            )
                                          : snapshot.data[index]['type'] ==
                                                  'pdf'
                                              ? InkWell(
                                                  onTap: () {
                                                    Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                            builder:
                                                                (context) =>
                                                                    showpdf(
                                                                      data: snapshot
                                                                              .data[
                                                                          index],
                                                                    )));
                                                  },
                                                  child: Center(
                                                      child: Image.asset(
                                                    "assets/pdf.png",
                                                    width: 100,
                                                    height: 100,
                                                  )))
                                              : const SizedBox.shrink(),
                                  verticalSpaceSmall,
                                  text_helper(
                                      data: snapshot.data[index]['time']
                                          .toString()
                                          .substring(0, 16),
                                      font: poppins,
                                      color: kcDarkGreyColor,
                                      size: fontSize10),
                                ],
                              ),
                            );
                          },
                        );
                      }
                    } else if (snapshot.hasError) {
                      return const Icon(
                        Icons.error,
                        color: kcDarkGreyColor,
                      );
                    } else {
                      return displaysimpleprogress(context);
                    }
                  },
                ),
              ),
              admin
                  ? Row(
                      children: [
                        horizontalSpaceSmall,
                        Expanded(
                            child: text_view_helper(
                          hint: "Enter Message",
                          controller: viewModel.text,
                          showicon: true,
                          icon: const Icon(Icons.message),
                        )),
                        horizontalSpaceSmall,
                        InkWell(
                            onTap: () => viewModel.pickPdfFile(id, context),
                            child: const Icon(
                              Icons.picture_as_pdf,
                              color: kcPrimaryColor,
                            )),
                        horizontalSpaceSmall,
                        InkWell(
                            onTap: () => viewModel.pic(id, context),
                            child: const Icon(
                              Icons.image,
                              color: kcPrimaryColor,
                            )),
                        horizontalSpaceSmall,
                        InkWell(
                            onTap: () => viewModel.send(id, context),
                            child: const Icon(
                              Icons.send,
                              color: golden,
                            )),
                        horizontalSpaceSmall,
                      ],
                    )
                  : const SizedBox.shrink()
            ],
          ),
        ));
  }

  @override
  InnerclassViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      InnerclassViewModel();
}
