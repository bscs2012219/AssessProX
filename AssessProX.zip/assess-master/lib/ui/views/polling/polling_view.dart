// ignore_for_file: prefer_interpolation_to_compose_strings

import 'package:assess/ui/common/app_strings.dart';
import 'package:assess/ui/common/ui_helpers.dart';
import 'package:assess/ui/common/uihelper/text_helper.dart';
import 'package:assess/ui/widgets/common/top/top.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../common/apihelpers/apihelper.dart';
import '../../common/app_colors.dart';
import '../../common/uihelper/snakbar_helper.dart';
import 'polling_viewmodel.dart';

class PollingView extends StackedView<PollingViewModel> {
  const PollingView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    PollingViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: Column(children: [
            Top(title: "Polling"),
            Expanded(
              child: FutureBuilder(
                future: ApiHelper.getpollbyuser(
                    viewModel.sharedpref.readString('number')),
                builder: (BuildContext context, AsyncSnapshot snapshot) {
                  if (snapshot.hasData) {
                    return ListView.builder(
                      itemCount: snapshot.data.length,
                      itemBuilder: (BuildContext context, int index) {
                        return Container(
                          width: screenWidth(context),
                          padding: const EdgeInsets.all(10),
                          margin: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: getColorWithOpacity(kcLightGrey, 0.1)),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              FutureBuilder(
                                future: ApiHelper.getonequizes(
                                    snapshot.data[index]['quizpin']),
                                builder: (BuildContext context,
                                    AsyncSnapshot<Map<dynamic, dynamic>>
                                        snapshot2) {
                                  if (snapshot2.hasData) {
                                    return Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        text_helper(
                                          data: snapshot2.data!['title'],
                                          font: poppins,
                                          color: kcPrimaryColor,
                                          size: fontSize14,
                                          bold: true,
                                        ),
                                        text_helper(
                                          data: snapshot2.data!['des'],
                                          font: poppins,
                                          color: kcLightGrey,
                                          size: fontSize12,
                                          bold: true,
                                        ),
                                      ],
                                    );
                                  } else if (snapshot2.hasError) {
                                    return const Icon(
                                      Icons.error,
                                      color: kcDarkGreyColor,
                                    );
                                  } else {
                                    return displaysimpleprogress(context);
                                  }
                                },
                              ),
                              text_helper(
                                data: "My Numbers : " +
                                    snapshot.data[index]['quiznumber'],
                                font: poppins,
                                color: kcPrimaryColor,
                                size: fontSize14,
                                bold: true,
                              ),
                            ],
                          ),
                        );
                      },
                    );
                  } else if (snapshot.hasError) {
                    return const Icon(
                      Icons.error,
                      color: kcDarkGreyColor,
                    );
                  } else {
                    return displaysimpleprogress(context);
                  }
                },
              ),
            )
          ]),
        ));
  }

  @override
  PollingViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      PollingViewModel();
}
