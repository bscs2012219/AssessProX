// ignore_for_file: must_be_immutable

import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/app_strings.dart';
import 'package:assess/ui/common/ui_helpers.dart';
import 'package:assess/ui/common/uihelper/text_helper.dart';
import 'package:custom_radio_grouped_button/custom_radio_grouped_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_timer_countdown/flutter_timer_countdown.dart';
import 'package:flutter_animation_progress_bar/flutter_animation_progress_bar.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:stacked/stacked.dart';

import '../../common/apihelpers/apihelper.dart';
import '../../common/uihelper/snakbar_helper.dart';
import 'solvequiz_viewmodel.dart';

class SolvequizView extends StackedView<SolvequizViewModel> {
  SolvequizView({Key? key, required this.pin}) : super(key: key);
  String pin;

  @override
  Widget builder(
    BuildContext context,
    SolvequizViewModel viewModel,
    Widget? child,
  ) {
    return WillPopScope(
      onWillPop: () async {
        return false;
      },
      child: Scaffold(
          backgroundColor: white,
          body: SafeArea(
            child: FutureBuilder(
                future: ApiHelper.getonequizes(pin),
                builder: (BuildContext context, AsyncSnapshot snapshot) {
                  if (snapshot.hasData) {
                    viewModel.first(snapshot.data['questionanswer']);
                    return Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: FAProgressBar(
                                  currentValue:
                                      viewModel.current.toDouble() + 1,
                                  displayText: "",
                                  maxValue: viewModel.qa.length.toDouble() + 1,
                                  displayTextStyle: text_helper.customstyle(
                                      montserrat,
                                      white,
                                      fontSize14,
                                      context,
                                      true),
                                  progressColor: kcPrimaryColor,
                                ),
                              ),
                              TimerCountdown(
                                format: CountDownTimerFormat.minutesSeconds,
                                enableDescriptions: false,
                                spacerWidth: 3,
                                timeTextStyle: text_helper.customstyle(
                                    poppins,
                                    kcDarkGreyColor,
                                    fontSize14,
                                    context,
                                    false),
                                endTime: DateTime.now().add(
                                  Duration(
                                    minutes:
                                        int.parse(snapshot.data['duration']),
                                    seconds: 0,
                                  ),
                                ),
                                onTick: (data) =>
                                    viewModel.notification(data.toString()),
                                onEnd: () => viewModel.back(
                                    context, snapshot.data['pin']),
                              ),
                            ],
                          ),
                          verticalSpaceSmall,
                          viewModel.check
                              ? Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    text_helper(
                                        data: viewModel.qa[viewModel.current]
                                                ['q']
                                            .toString()
                                            .toUpperCase(),
                                        bold: true,
                                        textAlign: TextAlign.start,
                                        font: poppins,
                                        color: kcPrimaryColor,
                                        size: fontSize14),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: CustomRadioButton(
                                          elevation: 5,
                                          unSelectedBorderColor: kcPrimaryColor,
                                          selectedBorderColor: kcPrimaryColor,
                                          horizontal: true,
                                          width: screenWidth(context),
                                          unSelectedColor: Colors.white,
                                          buttonLables: viewModel.cqa,
                                          buttonValues: viewModel.option,
                                          buttonTextStyle: ButtonTextStyle(
                                              selectedColor: Colors.white,
                                              unSelectedColor: Colors.black,
                                              selectedTextStyle:
                                                  GoogleFonts.poppins(
                                                      fontSize: fontSize22),
                                              textStyle: GoogleFonts.poppins(
                                                  fontSize: fontSize20)),
                                          radioButtonValue: (value) =>
                                              viewModel.updateindex(
                                                  value,
                                                  context,
                                                  snapshot.data['pin']),
                                          selectedColor: kcPrimaryColor),
                                    ),
                                  ],
                                )
                              : Expanded(child: displaysimpleprogress(context)),
                        ],
                      ),
                    );
                  } else if (snapshot.hasError) {
                    return const Icon(Icons.error_outline);
                  } else {
                    return displaysimpleprogress(context);
                  }
                }),
          )),
    );
  }

  @override
  SolvequizViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      SolvequizViewModel();
}
