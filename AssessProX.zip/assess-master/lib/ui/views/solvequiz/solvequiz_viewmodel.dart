// ignore_for_file: use_build_context_synchronously

import 'package:assess/ui/common/apihelpers/apihelper.dart';
import 'package:assess/ui/common/apihelpers/firebsaeuploadhelper.dart';
import 'package:assess/ui/common/uihelper/snakbar_helper.dart';
import 'package:flutter/widgets.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../services/sharedpref_service.dart';

class SolvequizViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final _sharedpref = locator<SharedprefService>();

  int current = 0;
  int correct = 0;
  List qa = [];
  List<String> cqa = [];
  List option = [];
  bool check = true;

  void first(List q) {
    qa = q;
    adddata(qa[current]);
  }

  void adddata(Map data) {
    cqa.clear();
    option.clear();
    if (data['a1'] != "") {
      cqa.add(data['a1']);
      option.add("A");
    }
    if (data['a2'] != "") {
      cqa.add(data['a2']);
      option.add("B");
    }
    if (data['a3'] != "") {
      cqa.add(data['a3']);
      option.add("C");
    }
    if (data['a4'] != "") {
      cqa.add(data['a4']);
      option.add("D");
    }
    if (data['a5'] != "") {
      cqa.add(data['a5']);
      option.add("E");
    }
  }

  Future<void> updateindex(
      String value, BuildContext context, String pin) async {
    if (value == qa[current]['correct']) {
      correct = correct + 1;
    }
    if (current < qa.length - 1) {
      check = false;
      await Future.delayed(const Duration(milliseconds: 500));
      notifyListeners();
      await Future.delayed(const Duration(seconds: 1));
      check = true;
      current = current + 1;
      adddata(qa[current]);
      notifyListeners();
    } else {
      back(context, pin);
    }
  }

  Future<void> back(BuildContext context, String pin) async {
    check = false;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 500));
    await ApiHelper.updateusers(pin);
    Map data = await ApiHelper.registerpoll(
        _sharedpref.readString('name'),
        _sharedpref.readString('number'),
        pin,
        correct.toString(),
        DateTime.now().toString().substring(0, 10),
        correct == qa.length ? "1" : "0",
        context);
    if (data['status']) {
      show_snackbar(context, "Completed Quiz");
      _navigationService.back();
    } else {
      show_snackbar(context, data['sucess']);
      _navigationService.back();
    }
  }

  void notification(String timeString) {
    List<String> timeComponents = timeString.split(':');
    int hours = int.parse(timeComponents[0]);
    int minutes = int.parse(timeComponents[1]);
    double seconds = double.parse(timeComponents[2]);
    Duration parsedDuration =
        Duration(hours: hours, minutes: minutes, seconds: seconds.toInt());
    if (parsedDuration.inSeconds < 5) {
      FirebaseHelper.sendnotificationto(
          _sharedpref.readString('deviceid'), "Quiz", "Complete your quiz");
    }
  }
}
