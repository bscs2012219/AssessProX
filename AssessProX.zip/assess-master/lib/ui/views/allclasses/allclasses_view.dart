import 'package:assess/ui/common/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../common/apihelpers/apihelper.dart';
import '../../common/app_strings.dart';
import '../../common/ui_helpers.dart';
import '../../common/uihelper/snakbar_helper.dart';
import '../../common/uihelper/text_helper.dart';
import '../../widgets/common/top/top.dart';
import 'allclasses_viewmodel.dart';

class AllclassesView extends StackedView<AllclassesViewModel> {
  const AllclassesView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    AllclassesViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: Column(
            children: [
              Top(
                title: "All Classes",
              ),
              Row(
                children: [
                  catbtn(context, viewModel, "All"),
                  catbtn(context, viewModel, "Joined"),
                  catbtn(context, viewModel, "My"),
                ],
              ),
              Expanded(
                child: FutureBuilder(
                  future: ApiHelper.allclass(),
                  builder: (BuildContext context, AsyncSnapshot snapshot) {
                    if (snapshot.hasData) {
                      if (snapshot.data.toString() == '[]') {
                        return Center(
                          child: text_helper(
                              data: "No Data",
                              font: poppins,
                              color: kcDarkGreyColor,
                              size: fontSize14),
                        );
                      } else {
                        return ListView.builder(
                          itemCount: snapshot.data.length,
                          itemBuilder: (BuildContext context, int index) {
                            if (viewModel.cat == "All") {
                              return listdate(
                                  snapshot.data[index], context, viewModel);
                            } else if (viewModel.cat == "My") {
                              if (viewModel.sharedpref.readString("number") ==
                                  snapshot.data[index]['addedby']) {
                                return listdate(
                                    snapshot.data[index], context, viewModel);
                              } else {
                                return const SizedBox.shrink();
                              }
                            } else if (viewModel.cat == "Joined") {
                              if (snapshot.data[index]['user'].contains(
                                  viewModel.sharedpref.readString("number"))) {
                                return listdate(
                                    snapshot.data[index], context, viewModel);
                              } else {
                                return const SizedBox.shrink();
                              }
                            } else {
                              return const SizedBox.shrink();
                            }
                          },
                        );
                      }
                    } else if (snapshot.hasError) {
                      return const Icon(
                        Icons.error,
                        color: kcDarkGreyColor,
                      );
                    } else {
                      return displaysimpleprogress(context);
                    }
                  },
                ),
              ),
            ],
          ),
        ));
  }

  Widget listdate(
      Map data, BuildContext context, AllclassesViewModel viewModel) {
    return InkWell(
      onTap: () async {
        if (data['addedby'] == viewModel.sharedpref.readString("number")) {
          viewModel.innerclass(data["_id"], true, data['title']);
        } else {
          bool c = await ApiHelper.classjoin(
              data["_id"], viewModel.sharedpref.readString("number"));
          if (c) {
            viewModel.innerclass(data["_id"], false, data['title']);
          } else {
            show_snackbar(context, "Try again later");
          }
        }
      },
      child: Container(
          padding: const EdgeInsets.all(10),
          margin: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: getColorWithOpacity(golden, 0.1),
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Image.asset(
                    "assets/class01.png",
                    width: 50,
                    height: 50,
                  ),
                  horizontalSpaceTiny,
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        text_helper(
                          data: data['title'],
                          font: poppins,
                          color: kcDarkGreyColor,
                          size: fontSize14,
                          bold: true,
                        ),
                        text_helper(
                            data: data['des'],
                            font: poppins,
                            textAlign: TextAlign.start,
                            color: kcDarkGreyColor,
                            size: fontSize12),
                      ],
                    ),
                  )
                ],
              ),
              verticalSpaceTiny,
              data['addedby'] == viewModel.sharedpref.readString("number")
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: text_helper(
                              data: data['code'],
                              overflow: TextOverflow.ellipsis,
                              font: poppins,
                              color: kcDarkGreyColor,
                              size: fontSize10),
                        ),
                        horizontalSpaceTiny,
                        InkWell(
                            onTap: () => viewModel.copy(data['code'], context),
                            child: const Icon(Icons.copy))
                      ],
                    )
                  : const Align(
                      alignment: Alignment.centerRight,
                      child: Icon(Icons.arrow_forward_ios_rounded),
                    ),
              verticalSpaceTiny
            ],
          )),
    );
  }

  Widget catbtn(
      BuildContext context, AllclassesViewModel viewModel, String text) {
    return InkWell(
      onTap: () {
        viewModel.cat = text;
        viewModel.notifyListeners();
      },
      child: Container(
        padding: const EdgeInsets.all(10),
        margin: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: viewModel.cat == text ? kcPrimaryColor : white,
          border: Border.all(color: kcPrimaryColor, width: 1),
        ),
        child: text_helper(
          data: text,
          font: poppins,
          color: viewModel.cat == text ? white : kcPrimaryColor,
          size: fontSize14,
          bold: true,
        ),
      ),
    );
  }

  @override
  AllclassesViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      AllclassesViewModel();
}
