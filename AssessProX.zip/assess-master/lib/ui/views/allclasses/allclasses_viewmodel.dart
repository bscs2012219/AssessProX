import 'package:assess/ui/common/uihelper/snakbar_helper.dart';
import 'package:assess/ui/views/innerclass/innerclass_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../services/sharedpref_service.dart';

class AllclassesViewModel extends BaseViewModel {
  final sharedpref = locator<SharedprefService>();
  final _navigationService = locator<NavigationService>();

  String cat = "All";

  Future<void> copy(String text, BuildContext context) async {
    await Clipboard.setData(ClipboardData(text: text));
    show_snackbar(context, "Class Code Copied");
  }

  void innerclass(String id, bool admin, String title) {
    _navigationService.navigateWithTransition(
        InnerclassView(
          id: id,
          admin: admin,
          title: title,
        ),
        routeName: Routes.innerclassView,
        transitionStyle: Transition.rightToLeft);
  }
}
