import 'package:assess/ui/common/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:stacked/stacked.dart';

import '../../common/uihelper/snakbar_helper.dart';
import 'startup_viewmodel.dart';

class StartupView extends StackedView<StartupViewModel> {
  const StartupView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    StartupViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
      backgroundColor: white,
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset("assets/fyp.png")
                  .animate(delay: 500.milliseconds)
                  .fade()
                  .scaleXY()
                  .moveY(begin: 50, end: 0)
                  .shakeX(delay: 700.milliseconds),
              displaysimpleprogress(context)
                  .animate(delay: 500.milliseconds)
                  .fade()
                  .scaleXY()
                  .moveY(begin: 50, end: 0)
                  .shakeX(delay: 700.milliseconds),
            ],
          ),
        ),
      ),
    );
  }

  @override
  StartupViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      StartupViewModel();

  @override
  void onViewModelReady(StartupViewModel viewModel) => SchedulerBinding.instance
      .addPostFrameCallback((timeStamp) => viewModel.runStartupLogic());
}
