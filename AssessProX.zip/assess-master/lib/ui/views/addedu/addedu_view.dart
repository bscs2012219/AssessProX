import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/app_strings.dart';
import 'package:assess/ui/common/ui_helpers.dart';
import 'package:assess/ui/common/uihelper/text_helper.dart';
import 'package:chips_choice/chips_choice.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:stacked/stacked.dart';

import '../../common/uihelper/button_helper.dart';
import '../../common/uihelper/text_veiw_helper.dart';
import 'addedu_viewmodel.dart';

class AddeduView extends StackedView<AddeduViewModel> {
  const AddeduView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    AddeduViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        appBar: AppBar(
            backgroundColor: golden,
            iconTheme: const IconThemeData(color: kcDarkGreyColor),
            title: text_helper(
              data: "Add Details",
              font: poppins,
              size: fontSize18,
              bold: true,
              color: kcDarkGreyColor,
            )),
        backgroundColor: white,
        body: SafeArea(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  text_helper(
                      data: "Add Education Details",
                      font: poppins,
                      bold: true,
                      color: kcPrimaryColor,
                      size: fontSize22),
                  verticalSpaceSmall,
                  text_view_helper(
                    hint: "Enter latest Education",
                    controller: viewModel.edu,
                    showicon: true,
                    icon: const Icon(Icons.school),
                  )
                      .animate(delay: 500.milliseconds)
                      .fade()
                      .moveY(begin: 50, end: 0),
                  verticalSpaceSmall,
                  text_helper(
                    data: "Select Your Major",
                    font: poppins,
                    color: kcDarkGreyColor,
                    size: fontSize14,
                    bold: true,
                  )
                      .animate(delay: 700.milliseconds)
                      .fade()
                      .moveY(begin: 50, end: 0),
                  ChipsChoice<int>.single(
                    value: viewModel.subject,
                    wrapped: true,
                    onChanged: (val) {
                      viewModel.subject = val;
                      viewModel.notifyListeners();
                    },
                    choiceStyle: const C2ChipStyle(
                      foregroundColor: kcPrimaryColor,
                    ),
                    choiceItems: C2Choice.listFrom<int, String>(
                      source: subjects,
                      value: (i, v) => i,
                      label: (i, v) => v,
                    ),
                  )
                      .animate(delay: 900.milliseconds)
                      .fade()
                      .moveY(begin: 50, end: 0),
                  Align(
                    alignment: Alignment.center,
                    child: button_helper(
                            onpress: () => viewModel.next(context),
                            color: kcPrimaryColor,
                            width: screenWidthCustom(context, 0.4),
                            padding: const EdgeInsetsDirectional.all(8),
                            child: text_helper(
                              data: "next",
                              font: poppins,
                              color: white,
                              size: fontSize18,
                              bold: true,
                            ))
                        .animate(delay: 1100.milliseconds)
                        .fade()
                        .moveY(begin: 50, end: 0),
                  ),
                ],
              ),
            ),
          ),
        ));
  }

  @override
  AddeduViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      AddeduViewModel();
}
