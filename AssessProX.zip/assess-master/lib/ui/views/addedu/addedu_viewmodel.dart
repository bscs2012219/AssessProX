import 'package:assess/ui/common/app_strings.dart';
import 'package:assess/ui/views/addpass/addpass_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../services/sharedpref_service.dart';
import '../../common/uihelper/snakbar_helper.dart';

class AddeduViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final _sharedpref = locator<SharedprefService>();

  TextEditingController edu = TextEditingController();
  int subject = 0;

  Future<void> next(BuildContext context) async {
    if (edu.text.isEmpty) {
      show_snackbar(context, "Enter lastest education degree");
    } else {
      _sharedpref.setString("lastdeg", edu.text);
      _sharedpref.setString("subject", subjects[subject]);
      _navigationService.navigateWithTransition(const AddpassView(),
          routeName: Routes.addpassView,
          transitionStyle: Transition.rightToLeft);
    }
  }
}
