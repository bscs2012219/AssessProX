// ignore_for_file: use_build_context_synchronously

import 'package:assess/ui/common/apihelpers/apihelper.dart';
import 'package:assess/ui/common/apihelpers/firebsaeuploadhelper.dart';
import 'package:assess/ui/common/uihelper/snakbar_helper.dart';
import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../common/app_strings.dart';

class NewquizViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();

  TextEditingController title = TextEditingController();
  TextEditingController descripton = TextEditingController();
  TextEditingController duration = TextEditingController();

  TextEditingController question = TextEditingController();
  TextEditingController answer01 = TextEditingController();
  TextEditingController answer02 = TextEditingController();
  TextEditingController answer03 = TextEditingController();
  TextEditingController answer04 = TextEditingController();
  TextEditingController answer05 = TextEditingController();

  int tag = 0;
  int subject = 0;
  List<String> options = ['A', 'B', 'C', 'D', 'E'];

  List qa = [];

  void addtolist(BuildContext context) {
    if (question.text.isEmpty) {
      show_snackbar(context, "Add a Question");
    } else if (answer01.text.isEmpty || answer02.text.isEmpty) {
      show_snackbar(context, "Add At least first 2 answers");
    } else if ((answer03.text.isEmpty && tag == 2) ||
        (answer04.text.isEmpty && tag == 3) ||
        (answer05.text.isEmpty && tag == 4)) {
      show_snackbar(context, "correct option chosen with filled answer");
    } else {
      qa.add({
        'q': question.text,
        'a1': answer01.text,
        'a2': answer02.text,
        'a3': answer03.text,
        'a4': answer04.text,
        'a5': answer05.text,
        'correct': options[tag]
      });
      clearqa();
    }
  }

  void update(Map e) {
    question.text = e['q'];
    answer01.text = e['a1'];
    answer02.text = e['a2'];
    answer03.text = e['a3'];
    answer04.text = e['a4'];
    answer05.text = e['a5'];
    tag = options.indexOf(e['correct']);
    delete(e['q']);
    notifyListeners();
  }

  void delete(String q) {
    for (int i = 0; i < qa.length; i++) {
      if (qa[i]['q'] == q) {
        qa.removeAt(i);
        notifyListeners();
        break;
      }
    }
  }

  Future<void> createlist(BuildContext context) async {
    if (title.text.isEmpty ||
        descripton.text.isEmpty ||
        duration.text.isEmpty) {
      show_snackbar(context, "Fill all quiz details");
    } else if (qa.isEmpty) {
      show_snackbar(context, "Enter at least one question");
    } else {
      displayprogress(context);
      var pin = await ApiHelper.pinnumber();
      var data = await ApiHelper.registerquiz(title.text, descripton.text,
          subjects[subject], pin.toString(), duration.text, qa, context);
      if (data['status']) {
        await FirebaseHelper.sendallnotification(
            "New Quiz", "Solve this quiz to get more points");
        hideprogress(context);
        _navigationService.back();
        show_snackbar(context, data['sucess']);
      } else {
        hideprogress(context);
        show_snackbar(context, data['sucess']);
      }
    }
  }

  void clearqa() {
    question.clear();
    answer01.clear();
    answer02.clear();
    answer03.clear();
    answer04.clear();
    answer05.clear();
    tag = 0;
    notifyListeners();
  }
}
