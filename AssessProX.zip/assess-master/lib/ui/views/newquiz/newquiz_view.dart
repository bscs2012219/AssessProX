import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/app_strings.dart';
import 'package:assess/ui/common/ui_helpers.dart';
import 'package:assess/ui/common/uihelper/button_helper.dart';
import 'package:assess/ui/common/uihelper/text_helper.dart';
import 'package:assess/ui/common/uihelper/text_veiw_helper.dart';
import 'package:chips_choice/chips_choice.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:stacked/stacked.dart';

import 'newquiz_viewmodel.dart';

class NewquizView extends StackedView<NewquizViewModel> {
  const NewquizView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    NewquizViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        appBar: AppBar(
          backgroundColor: white,
          iconTheme: const IconThemeData(color: kcPrimaryColor),
          title: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset(
                'assets/quiz3.png',
                width: screenWidthCustom(context, 0.08),
                height: screenWidthCustom(context, 0.08),
              ),
              text_helper(
                data: "Create New Quiz",
                font: montserrat,
                color: kcPrimaryColor,
                size: fontSize18,
                bold: true,
                overflow: TextOverflow.ellipsis,
              )
            ],
          ),
        ),
        body: SafeArea(
          child: ListView(
            children: [
              Container(
                margin: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: getColorWithOpacity(kcVeryLightGrey, 0.5),
                ),
                child: Column(
                  children: [
                    texthelper(viewModel.title, "Enter Title", Icons.title, 1),
                    texthelper(viewModel.descripton, "Enter Description",
                        Icons.description_outlined, 1),
                    Container(
                      margin: const EdgeInsets.fromLTRB(10, 15, 10, 10),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(width: 1, color: kcLightGrey)),
                      child: text_view_helper(
                        hint: "Enter Duration in minutes",
                        width: screenWidth(context),
                        controller: viewModel.duration,
                        textInputType: TextInputType.number,
                        formatter: [
                          FilteringTextInputFormatter.allow(getRegExpint())
                        ],
                        showicon: true,
                        padding: const EdgeInsetsDirectional.all(0),
                        margin: const EdgeInsetsDirectional.all(0),
                        maxline: null,
                        inputBorder: InputBorder.none,
                        icon: const Icon(
                          Icons.punch_clock_outlined,
                          color: kcPrimaryColor,
                        ),
                      ),
                    ),
                    ChipsChoice<int>.single(
                      value: viewModel.subject,
                      wrapped: true,
                      onChanged: (val) {
                        viewModel.subject = val;
                        viewModel.notifyListeners();
                      },
                      choiceStyle: const C2ChipStyle(
                        foregroundColor: kcPrimaryColor,
                      ),
                      choiceItems: C2Choice.listFrom<int, String>(
                        source: subjects,
                        value: (i, v) => i,
                        label: (i, v) => v,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: getColorWithOpacity(kcVeryLightGrey, 0.2),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(10, 15, 10, 10),
                      child: text_helper(
                          data: "Question No. ${viewModel.qa.length}",
                          bold: true,
                          font: montserrat,
                          color: kcDarkGreyColor,
                          size: fontSize14),
                    ),
                    texthelper(
                        viewModel.question,
                        "Enter Question No ${viewModel.qa.length}",
                        Icons.question_mark,
                        1),
                    horizontalSpaceSmall,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          height: 350,
                          width: 1,
                          color: kcPrimaryColor,
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            texthelper(viewModel.answer01, "Enter Answer 01",
                                Icons.question_answer_outlined, 0.4),
                            texthelper(viewModel.answer02, "Enter Answer 02",
                                Icons.question_answer_outlined, 0.4),
                            texthelper(viewModel.answer03, "Enter Answer 03",
                                Icons.question_answer_outlined, 0.4),
                            texthelper(viewModel.answer04, "Enter Answer 04",
                                Icons.question_answer_outlined, 0.4),
                            texthelper(viewModel.answer05, "Enter Answer 05",
                                Icons.question_answer_outlined, 0.4),
                          ],
                        ),
                      ],
                    ),
                    ChipsChoice<int>.single(
                      value: viewModel.tag,
                      onChanged: (val) {
                        viewModel.tag = val;
                        viewModel.notifyListeners();
                      },
                      choiceStyle: const C2ChipStyle(
                        foregroundColor: kcPrimaryColor,
                      ),
                      choiceItems: C2Choice.listFrom<int, String>(
                        source: viewModel.options,
                        value: (i, v) => i,
                        label: (i, v) => v,
                      ),
                    ),
                    Align(
                      alignment: Alignment.center,
                      child: button_helper(
                          onpress: () => viewModel.addtolist(context),
                          color: kcPrimaryColor,
                          width: screenWidthCustom(context, 0.4),
                          raduis: 30,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              const Icon(
                                Icons.add,
                                color: white,
                              ),
                              horizontalSpaceTiny,
                              text_helper(
                                  data: "Add Another",
                                  font: poppins,
                                  color: white,
                                  size: fontSize12),
                            ],
                          )),
                    ),
                    verticalSpaceSmall,
                  ],
                ),
              ),
              Column(
                children: viewModel.qa.map((e) {
                  return Container(
                    padding: const EdgeInsets.all(10),
                    margin: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: getColorWithOpacity(kcVeryLightGrey, 0.1),
                    ),
                    child: Column(
                      children: [
                        qlist('q', e['q'], e['correct'], context),
                        Row(
                          children: [
                            horizontalSpaceMedium,
                            Expanded(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  qlist("A", e['a1'], e['correct'], context),
                                  qlist("B", e['a2'], e['correct'], context),
                                  qlist("C", e['a3'], e['correct'], context),
                                  qlist("D", e['a4'], e['correct'], context),
                                  qlist("E", e['a5'], e['correct'], context),
                                ],
                              ),
                            )
                          ],
                        ),
                        Row(
                          children: [
                            button_helper(
                                onpress: () => viewModel.update(e),
                                color: kcVeryLightGrey,
                                width: screenWidthCustom(context, 0.3),
                                child: text_helper(
                                    data: "update",
                                    font: poppins,
                                    color: kcDarkGreyColor,
                                    size: fontSize12)),
                            button_helper(
                                onpress: () => viewModel.delete(e['q']),
                                color: kcVeryLightGrey,
                                width: screenWidthCustom(context, 0.3),
                                child: text_helper(
                                    data: "delete",
                                    font: poppins,
                                    color: kcDarkGreyColor,
                                    size: fontSize12))
                          ],
                        )
                      ],
                    ),
                  );
                }).toList(),
              ),
              button_helper(
                  onpress: () => viewModel.createlist(context),
                  color: kcPrimaryColor,
                  width: screenWidthCustom(context, 0.4),
                  raduis: 10,
                  child: text_helper(
                      data: "Create Quiz",
                      font: poppins,
                      color: white,
                      size: fontSize12)),
            ],
          ),
        ));
  }

  Widget texthelper(TextEditingController controller, String title,
      IconData iconData, double width) {
    return Container(
      margin: const EdgeInsets.fromLTRB(10, 15, 10, 10),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(width: 1, color: kcLightGrey)),
      child: text_view_helper(
        hint: title,
        width: width,
        controller: controller,
        showicon: true,
        padding: const EdgeInsetsDirectional.all(0),
        margin: const EdgeInsetsDirectional.all(0),
        maxline: null,
        inputBorder: InputBorder.none,
        icon: Icon(
          iconData,
          color: kcPrimaryColor,
        ),
      ),
    );
  }

  Widget qlist(String a, String b, String c, BuildContext context) {
    return b != ''
        ? Row(
            children: [
              text_helper(
                data: a.toUpperCase(),
                font: poppins,
                color: kcPrimaryColor,
                size: fontSize14,
                bold: true,
              ),
              horizontalSpaceSmall,
              a == c
                  ? const Row(
                      children: [
                        Icon(
                          Icons.check,
                          color: kcPrimaryColor,
                        ),
                        horizontalSpaceSmall
                      ],
                    )
                  : const SizedBox.shrink(),
              Expanded(
                child: text_helper(
                    data: b,
                    font: poppins,
                    textAlign: TextAlign.start,
                    color: kcDarkGreyColor,
                    size: fontSize14),
              ),
            ],
          )
        : const SizedBox.shrink();
  }

  @override
  void onDispose(NewquizViewModel viewModel) {
    viewModel.title.dispose();
    viewModel.descripton.dispose();
    viewModel.duration.dispose();
    viewModel.question.dispose();
    viewModel.answer01.dispose();
    viewModel.answer02.dispose();
    viewModel.answer03.dispose();
    viewModel.answer04.dispose();
    viewModel.answer05.dispose();
  }

  @override
  NewquizViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      NewquizViewModel();
}
