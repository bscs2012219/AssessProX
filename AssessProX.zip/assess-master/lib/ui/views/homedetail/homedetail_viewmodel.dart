import 'package:assess/ui/views/allclasses/allclasses_view.dart';
import 'package:assess/ui/views/marketplace/marketplace_view.dart';
import 'package:assess/ui/views/mocktest/mocktest_view.dart';
import 'package:assess/ui/views/myorders/myorders_view.dart';
import 'package:assess/ui/views/wallet/wallet_view.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../services/sharedpref_service.dart';
import '../marketplaceaddgoods/marketplaceaddgoods_view.dart';

class HomedetailViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final sharedpref = locator<SharedprefService>();

  void visit() {
    _navigationService.navigateWithTransition(MarketplaceView(),
        routeName: Routes.marketplaceView,
        transitionStyle: Transition.rightToLeft);
  }

  void download() {
    _navigationService.navigateWithTransition(const MyordersView(),
        routeName: Routes.myordersView,
        transitionStyle: Transition.rightToLeft);
  }

  void wallet() {
    _navigationService.navigateWithTransition(const WalletView(),
        routeName: Routes.walletView, transitionStyle: Transition.rightToLeft);
  }

  void add() {
    _navigationService.navigateWithTransition(const MarketplaceaddgoodsView(),
        routeName: Routes.marketplaceaddgoodsView,
        transitionStyle: Transition.rightToLeft);
  }

  void mocktest() {
    _navigationService.navigateWithTransition(const MocktestView(),
        routeName: Routes.mocktestView,
        transitionStyle: Transition.rightToLeft);
  }

  void allclasses() {
    _navigationService.navigateWithTransition(const AllclassesView(),
        routeName: Routes.allclassesView,
        transitionStyle: Transition.rightToLeft);
  }
}
