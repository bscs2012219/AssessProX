// ignore_for_file: prefer_interpolation_to_compose_strings

import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/app_strings.dart';
import 'package:assess/ui/common/ui_helpers.dart';
import 'package:assess/ui/common/uihelper/snakbar_helper.dart';
import 'package:assess/ui/common/uihelper/text_helper.dart';
import 'package:assess/ui/widgets/common/joinclassbycode/joinclassbycode.dart';
import 'package:assess/ui/widgets/common/newclass/newclass.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:stacked/stacked.dart';

import '../../common/apihelpers/apihelper.dart';
import '../../widgets/common/customslider/customslider.dart';
import '../../widgets/common/tophelper/tophelper.dart';
import 'homedetail_viewmodel.dart';

class HomedetailView extends StackedView<HomedetailViewModel> {
  const HomedetailView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    HomedetailViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
      backgroundColor: white,
      body: SafeArea(
        child: ListView(
          children: [
            top(context, viewModel),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Tophelper(
                    function: () => viewModel.download(),
                    icon: "assets/download.png",
                    text: "Your\nDownload",
                  ),
                  horizontalSpaceSmall,
                  Tophelper(
                      function: () => viewModel.wallet(),
                      icon: "assets/wallet.png",
                      text: "Your\nWallet"),
                  horizontalSpaceSmall,
                  Tophelper(
                      function: () => viewModel.add(),
                      icon: "assets/add22.png",
                      text: "Sell\nProduct"),
                  horizontalSpaceSmall,
                  Tophelper(
                      function: () => viewModel.mocktest(),
                      icon: "assets/test.png",
                      text: "Mock\nTest"),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Tophelper(
                    function: () => addclass(context),
                    icon: "assets/class01.png",
                    text: "Add\nClass",
                  ),
                  horizontalSpaceSmall,
                  Tophelper(
                      function: () => viewModel.allclasses(),
                      icon: "assets/class02.png",
                      text: "All\nClasses"),
                  horizontalSpaceSmall,
                  Tophelper(
                      function: () => classcode(context),
                      icon: "assets/class03.png",
                      text: "class\nCode"),
                  horizontalSpaceSmall,
                  const Expanded(child: SizedBox.shrink()),
                ],
              ),
            ),
            market(context, viewModel)
                .animate(delay: 300.ms)
                .fade()
                .moveY(begin: 50, end: 0),
          ],
        ),
      ),
    );
  }

  void classcode(BuildContext context) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return const Dialog(
            backgroundColor: white,
            child: Joinclassbycode(),
          );
        });
  }

  void addclass(BuildContext context) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return const Dialog(
            backgroundColor: white,
            child: Newclass(),
          );
        });
  }

  Widget pointsteak(BuildContext context, HomedetailViewModel viewModel) {
    return FutureBuilder(
      future: getuserpoint(context, viewModel),
      builder: (BuildContext context, AsyncSnapshot snapshot) {
        if (snapshot.hasData) {
          return Row(
            children: [
              horizontalSpaceSmall,
              Stack(
                children: [
                  Image.asset(
                    'assets/point.png',
                    width: screenWidthCustom(context, 0.2),
                  ),
                  Positioned.fill(
                      top: screenWidthCustom(context, 0.062),
                      bottom: 0,
                      left: 0,
                      right: 0,
                      child: text_helper(
                        data: snapshot.data['point'],
                        font: poppins,
                        color: kcDarkGreyColor,
                        size: fontSize18,
                        bold: true,
                      )),
                ],
              ),
              horizontalSpaceSmall,
              Stack(
                children: [
                  Image.asset(
                    'assets/streak.png',
                    width: screenWidthCustom(context, 0.2),
                  ),
                  Positioned.fill(
                      top: screenWidthCustom(context, 0.062),
                      bottom: 0,
                      left: 0,
                      right: 0,
                      child: text_helper(
                        data: "Streak\n" + snapshot.data['streak'],
                        font: poppins,
                        color: white,
                        size: fontSize8,
                        bold: true,
                      )),
                ],
              ),
            ],
          );
        } else if (snapshot.hasError) {
          return const Icon(
            Icons.error,
            color: kcDarkGreyColor,
          );
        } else {
          return displaysimpleprogress(context);
        }
      },
    );
  }

  Future<Map> getuserpoint(
      BuildContext context, HomedetailViewModel viewModel) async {
    Map data =
        await ApiHelper.oneuserdata(viewModel.sharedpref.readString('number'));
    String point = checkRange(int.parse(data['points'].toString()));
    String streak = data['streak'];
    return {"point": point, "streak": streak};
  }

  String checkRange(int value) {
    if (value < 10) {
      return "1";
    } else if (value < 30) {
      return "2";
    } else if (value < 70) {
      return "3";
    } else if (value < 150) {
      return "4";
    } else if (value < 300) {
      return "5";
    } else if (value < 600) {
      return "6";
    } else if (value < 1500) {
      return "7";
    } else {
      return "8";
    }
  }

  Widget top(BuildContext context, HomedetailViewModel viewModel) {
    return Container(
      width: screenWidth(context),
      decoration: const BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [golden, white])),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    text_helper(
                            data: "Hy Welcome To Acess Pro ",
                            font: poppins,
                            color: white,
                            bold: true,
                            size: fontSize16)
                        .animate(delay: 300.ms)
                        .fade()
                        .moveX(begin: -50, end: 0),
                    Row(
                      children: [
                        text_helper(
                          data: viewModel.sharedpref.readString("name"),
                          font: poppins,
                          color: kcDarkGreyColor,
                          size: fontSize22,
                          bold: true,
                        ),
                        verticalSpaceTiny,
                        Image.asset(
                          "assets/hand.png",
                          width: screenHeightCustom(context, 0.07),
                          height: screenWidthCustom(context, 0.07),
                        )
                      ],
                    ).animate(delay: 300.ms).fade().moveX(begin: -50, end: 0)
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(50),
                    child: CachedNetworkImage(
                      imageUrl: viewModel.sharedpref.readString("img"),
                      placeholder: (context, url) =>
                          displaysimpleprogress(context),
                      errorWidget: (context, url, error) =>
                          const Icon(Icons.error),
                      width: screenWidthCustom(context, 0.1),
                      height: screenWidthCustom(context, 0.1),
                      fit: BoxFit.cover,
                    ),
                  ),
                ).animate(delay: 300.ms).fade().moveX(begin: 50, end: 0),
              ],
            ),
            verticalSpaceSmall,
            CarouselSlider(
              items: carouselImages.map((i) {
                return Builder(
                  builder: (BuildContext context) => ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: CachedNetworkImage(
                      imageUrl: i,
                      imageBuilder: (context, imageProvider) => Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 5),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: imageProvider,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                      ),
                      placeholder: (context, url) =>
                          displaysimpleprogress(context),
                      errorWidget: (context, url, error) => const Icon(
                        Icons.error,
                        color: kcDarkGreyColor,
                      ),
                    ),
                  ),
                );
              }).toList(),
              options: CarouselOptions(autoPlay: true, aspectRatio: 25 / 9),
            ).animate(delay: 200.ms).fade().moveY(begin: 50, end: 0),
            verticalSpaceSmall,
            pointsteak(context, viewModel)
                .animate(delay: 300.ms)
                .fade()
                .moveY(begin: 50, end: 0),
          ],
        ),
      ),
    );
  }

  Widget market(BuildContext context, HomedetailViewModel viewModel) {
    return Container(
      width: screenWidth(context),
      padding: const EdgeInsets.all(10),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: getColorWithOpacity(kcLightGrey, 0.1)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                text_helper(
                        data: "Market Place",
                        bold: true,
                        font: poppins,
                        color: kcPrimaryColor,
                        size: fontSize14)
                    .animate(delay: 1100.ms)
                    .fade()
                    .moveX(begin: -50, end: 0),
                // Row(
                //   children: [
                //     Tophelper(
                //         function: () => viewModel.download(),
                //         icon: "assets/download.png"),
                //     horizontalSpaceSmall,
                //     Tophelper(
                //         function: () => viewModel.wallet(), icon: "assets/wallet.png"),
                //     horizontalSpaceSmall,
                //     Tophelper(
                //         function: () => viewModel.visit(),
                //         icon: "assets/arrowf.png"),
                //   ],
                // ),
              ],
            ),
          ),
          SizedBox(
            width: screenWidth(context),
            height: screenHeightCustom(context, 0.23),
            child: FutureBuilder(
              future: ApiHelper.getallmarket(),
              builder: (BuildContext context, AsyncSnapshot snapshot) {
                if (snapshot.hasData) {
                  return ListView.builder(
                    itemCount: snapshot.data.length,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (BuildContext context, int index) {
                      return InkWell(
                        onTap: () => viewModel.visit(),
                        child: Container(
                          width: screenWidthCustom(context, 0.3),
                          padding: const EdgeInsets.all(5),
                          margin: const EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: getColorWithOpacity(white, 1)),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Customslider(
                                  data: snapshot.data[index]['url'], h: 0.2),
                              verticalSpaceTiny,
                              text_helper(
                                data: snapshot.data[index]['title'],
                                font: poppins,
                                color: kcPrimaryColor,
                                size: fontSize12,
                                lines: 1,
                                overflow: TextOverflow.ellipsis,
                                bold: true,
                              ),
                              text_helper(
                                data: "\$ " + snapshot.data[index]['price'],
                                font: poppins,
                                color: golden,
                                size: fontSize10,
                                bold: true,
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                } else if (snapshot.hasError) {
                  return const Icon(
                    Icons.error,
                    color: kcDarkGreyColor,
                  );
                } else {
                  return displaysimpleprogress(context);
                }
              },
            ),
          )
        ],
      ),
    );
  }

  @override
  Future<void> onViewModelReady(HomedetailViewModel viewModel) async {
    await Permission.notification.request();
    super.onViewModelReady(viewModel);
  }

  @override
  HomedetailViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      HomedetailViewModel();
}
