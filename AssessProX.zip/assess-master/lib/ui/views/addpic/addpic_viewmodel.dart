// ignore_for_file: use_build_context_synchronously

import 'dart:io';

import 'package:assess/ui/views/addedu/addedu_view.dart';
import 'package:assess/ui/views/addpass/addpass_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';
import 'package:image_picker/image_picker.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../services/sharedpref_service.dart';
import '../../common/apihelpers/firebsaeuploadhelper.dart';
import '../../common/uihelper/snakbar_helper.dart';

class AddpicViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final _sharedpref = locator<SharedprefService>();

  File? image;

  Future<void> pic() async {
    final pickedFile =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      image = File(pickedFile.path);
      notifyListeners();
    }
  }

  Future<void> next(BuildContext context) async {
    if (image == null) {
      show_snackbar(context, "addpic");
    } else {
      displayprogress(context);
      String url = await FirebaseHelper.uploadFile(
          image, _sharedpref.readString('number'));
      _sharedpref.setString('img', url);
      hideprogress(context);
      _navigationService.navigateWithTransition(const AddeduView(),
          routeName: Routes.addeduView,
          transitionStyle: Transition.rightToLeft);
    }
  }
}
