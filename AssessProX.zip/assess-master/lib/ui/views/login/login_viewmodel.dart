import 'package:flutter/cupertino.dart';
import 'package:flutter_masked_text2/flutter_masked_text2.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../services/fire_service.dart';
import '../../../services/sharedpref_service.dart';
import '../../common/apihelpers/apihelper.dart';
import '../../common/uihelper/snakbar_helper.dart';
import '../home/home_view.dart';
import '../signup/signup_view.dart';

class LoginViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final _sharedpref = locator<SharedprefService>();
  final _fireService = locator<FireService>();

  TextEditingController phone = MaskedTextController(mask: '0000-0000000');
  TextEditingController pass = TextEditingController();

  void login(BuildContext context) {
    if (phone.text.isEmpty || pass.text.isEmpty) {
      show_snackbar(context, "Fill all fields");
    } else {
      displayprogress(context);
      var result = _fireService.messaging.getToken().then((value) {
        return ApiHelper.login(
            phone.text, pass.text, value.toString(), context);
      });
      result.then((value) {
        _sharedpref.setString('name', value['name']);
        _sharedpref.setString('cnic', value['cnic']);
        _sharedpref.setString('number', phone.text);
        _sharedpref.setString('lastdeg', value['lastdeg']);
        _sharedpref.setString('subject', value['subject']);
        _sharedpref.setString('address', value['address']);
        _sharedpref.setString('dob', value['dob']);
        _sharedpref.setString('img', value['img']);
        _sharedpref.setString('deviceid', value.toString());

        _sharedpref.setString("auth", "true");
        hideprogress(context);

        _navigationService.clearStackAndShow(Routes.homeView);
        _navigationService.replaceWithTransition(const HomeView(),
            routeName: Routes.homeView,
            transitionStyle: Transition.rightToLeft);
      });
    }
  }

  void signup() {
    _navigationService.navigateWithTransition(const SignupView(),
        routeName: Routes.signupView, transitionStyle: Transition.fade);
  }
}
