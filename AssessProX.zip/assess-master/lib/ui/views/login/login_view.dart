import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/ui_helpers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:lottie/lottie.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_strings.dart';
import '../../common/uihelper/button_helper.dart';
import '../../common/uihelper/text_helper.dart';
import '../../common/uihelper/text_veiw_helper.dart';
import 'login_viewmodel.dart';

class LoginView extends StackedView<LoginViewModel> {
  const LoginView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    LoginViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Lottie.asset(
                  'assets/login.json',
                  width: screenWidthCustom(context, 0.8),
                  height: screenWidthCustom(context, 0.6),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
                  child: Column(
                    children: [
                      text_view_helper(
                        hint: "Enter Phone",
                        controller: viewModel.phone,
                        textInputType: TextInputType.phone,
                        maxlength: 11,
                        formatter: [
                          FilteringTextInputFormatter.allow(getRegExpint())
                        ],
                        showicon: true,
                        icon: const Icon(Icons.phone),
                      )
                          .animate(delay: 900.milliseconds)
                          .fade()
                          .moveY(begin: 50, end: 0),
                      text_view_helper(
                        hint: "Enter Password",
                        controller: viewModel.pass,
                        showicon: true,
                        obsecure: true,
                        icon: const Icon(Icons.password),
                      )
                          .animate(delay: 1100.milliseconds)
                          .fade()
                          .moveY(begin: 50, end: 0),
                    ],
                  ),
                ),
                button_helper(
                        onpress: () => viewModel.login(context),
                        color: kcPrimaryColor,
                        width: screenWidthCustom(context, 0.4),
                        child: text_helper(
                            data: "Login",
                            font: poppins,
                            color: white,
                            bold: true,
                            size: fontSize18))
                    .animate(delay: 1300.milliseconds)
                    .fade()
                    .moveY(begin: 50, end: 0),
                const SizedBox(
                  height: 20,
                ),
                InkWell(
                  onTap: () => viewModel.signup(),
                  child: text_helper(
                      data: "Click here to signup",
                      font: poppins,
                      color: kcPrimaryColor,
                      size: fontSize12),
                )
                    .animate(delay: 1500.milliseconds)
                    .fade()
                    .moveY(begin: 50, end: 0)
              ],
            ),
          ),
        ));
  }

  @override
  LoginViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      LoginViewModel();
}
