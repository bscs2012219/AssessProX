// ignore_for_file: must_be_immutable

import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/app_strings.dart';
import 'package:assess/ui/common/ui_helpers.dart';
import 'package:assess/ui/common/uihelper/text_helper.dart';
import 'package:assess/ui/widgets/common/top/top.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../common/apihelpers/apihelper.dart';
import '../../common/uihelper/snakbar_helper.dart';
import 'leaderboard_viewmodel.dart';

class LeaderboardView extends StackedView<LeaderboardViewModel> {
  LeaderboardView({Key? key, required this.pin}) : super(key: key);
  String pin;

  @override
  Widget builder(
    BuildContext context,
    LeaderboardViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: Column(
            children: [
              Top(title: "Leader Board",),
              Expanded(
                child: FutureBuilder(
                    future: ApiHelper.getpollbynumber(pin),
                    builder: (BuildContext context, AsyncSnapshot snapshot) {
                      if (snapshot.hasData) {
                        viewModel.first(snapshot.data);
                        if (snapshot.data.length != 0) {
                          if (viewModel.bottom.isNotEmpty) {
                            return ListView.builder(
                              itemCount: viewModel.bottom.length,
                              itemBuilder: (BuildContext context, int index) {
                                if (index == 0) {
                                  return Column(
                                    children: [
                                      topstack(context, viewModel),
                                      listview(
                                          context, viewModel.bottom[index], index)
                                    ],
                                  );
                                } else {
                                  return listview(
                                      context, viewModel.bottom[index], index);
                                }
                              },
                            );
                          } else {
                            return topstack(context, viewModel);
                          }
                        } else {
                          return Column(
                            children: [
                              Container(
                                width: screenWidth(context),
                                padding: const EdgeInsets.all(20),
                                margin: const EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                    color: kcPrimaryColor,
                                    borderRadius: BorderRadius.circular(10)),
                                child: text_helper(
                                    data: "Leader Board",
                                    font: poppins,
                                    color: white,
                                    size: fontSize18),
                              ),
                              text_helper(
                                  data: "No Data Avaliable",
                                  font: poppins,
                                  color: kcPrimaryColor,
                                  size: fontSize14),
                            ],
                          );
                        }
                      } else if (snapshot.hasError) {
                        return const Icon(Icons.error_outline);
                      } else {
                        return displaysimpleprogress(context);
                      }
                    }),
              )
            ]
          ),
        ));
  }

  Widget topstack(BuildContext context, LeaderboardViewModel viewModel) {
    return SizedBox(
      width: screenWidth(context),
      height: screenHeightCustom(context, 0.45),
      child: Stack(
        children: [
          Opacity(
            opacity: 0.03,
            child: Image.asset(
              'assets/leaderboard.jpg',
              width: screenWidth(context),
              height: screenHeightCustom(context, 0.4),
              fit: BoxFit.cover,
            ),
          ),
          Container(
            width: screenWidth(context),
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    stops: const [0, 0.07],
                    colors: [white, getColorWithOpacity(white, 0)])),
          ),
          Positioned(
            left: 0,
            right: 0,
            top: 20,
            child: text_helper(
                data: "Check Winners",
                font: montserrat,
                bold: true,
                color: kcDarkGreyColor,
                size: fontSize22),
          ),
          Positioned(
            bottom: 0,
            right: 0,
            left: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                toplistview(context, 1, 0.2, viewModel),
                toplistview(context, 0, 0.3, viewModel),
                toplistview(context, 2, 0.2, viewModel)
              ],
            ),
          ),
          Positioned(
            top: screenHeightCustom(context, 0.21),
            left: screenWidthCustom(context, 0.1),
            child: star(context),
          ),
          Positioned(
            top: screenHeightCustom(context, 0.11),
            left: screenWidthCustom(context, 0.44),
            child: star(context),
          ),
          Positioned(
            top: screenHeightCustom(context, 0.21),
            right: screenWidthCustom(context, 0.1),
            child: star(context),
          ),
        ],
      ),
    );
  }

  Widget toplistview(BuildContext context, int index, double height,
      LeaderboardViewModel viewModel) {
    return Container(
      width: screenWidthCustom(context, 0.3333),
      height: screenHeightCustom(context, height),
      decoration: const BoxDecoration(
          color: kcPrimaryColor,
          borderRadius: BorderRadius.only(
              topRight: Radius.circular(20), topLeft: Radius.circular(20))),
      child: viewModel.top[index].toString() != '{}'
          ? Column(
              children: [
                verticalSpaceMedium,
                Container(
                  margin: const EdgeInsets.only(top: 5),
                  padding: const EdgeInsets.only(bottom: 3, left: 2),
                  decoration: BoxDecoration(
                      color: golden, borderRadius: BorderRadius.circular(50)),
                  child: FutureBuilder(
                      future: ApiHelper.userbynum(
                          viewModel.top[index]['usernumber']),
                      builder: (BuildContext context, AsyncSnapshot snapshot) {
                        if (snapshot.hasData) {
                          return ClipRRect(
                            borderRadius: BorderRadius.circular(50),
                            child: CachedNetworkImage(
                              imageUrl: snapshot.data,
                              placeholder: (context, url) =>
                                  displaysimpleprogress(context),
                              errorWidget: (context, url, error) =>
                                  const Icon(Icons.error),
                              width: screenWidthCustom(context, 0.1),
                              height: screenWidthCustom(context, 0.1),
                              fit: BoxFit.cover,
                            ),
                          );
                        } else if (snapshot.hasError) {
                          return const Icon(Icons.error_outline);
                        } else {
                          return displaysimpleprogress(context);
                        }
                      }),
                ),
                text_helper(
                    data: viewModel.top[index]["username"],
                    bold: true,
                    font: montserrat,
                    color: white,
                    size: fontSize18),
                text_helper(
                    data: viewModel.top[index]["quiznumber"],
                    font: montserrat,
                    color: white,
                    size: fontSize14),
              ],
            )
          : const SizedBox.shrink(),
    );
  }

  Widget listview(BuildContext context, Map data, int index) {
    return Container(
      width: screenWidth(context),
      color: kcPrimaryColor,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              children: [
                Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(50),
                        color: getColorWithOpacity(kcVeryLightGrey, 0.5)),
                    child: text_helper(
                        data: "${index + 3}",
                        font: poppins,
                        color: white,
                        size: fontSize14)),
                horizontalSpaceSmall,
                text_helper(
                    data: data['username'].toString().toUpperCase(),
                    font: montserrat,
                    bold: true,
                    color: white,
                    size: fontSize14),
              ],
            ),
            text_helper(
                data: data['quiznumber'] + " num",
                font: montserrat,
                color: white,
                size: fontSize14),
          ],
        ),
      ),
    );
  }

  Widget star(BuildContext context) {
    return Image.asset(
      'assets/star.jpg',
      width: screenWidthCustom(context, 0.12),
    );
  }

  @override
  LeaderboardViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      LeaderboardViewModel();
}
