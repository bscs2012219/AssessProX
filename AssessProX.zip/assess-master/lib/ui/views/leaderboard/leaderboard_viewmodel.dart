import 'package:stacked/stacked.dart';

class LeaderboardViewModel extends BaseViewModel {
  List top = [];
  List bottom = [];

  void first(List data) {
    top.clear();
    bottom.clear();
    for (int i = 0; i < data.length; i++) {
      if (i == 0 || i == 1 || i == 2) {
        top.add(data[i]);
      } else {
        bottom.add(data[i]);
      }
    }
    if (top.length == 1) {
      top.add({});
      top.add({});
    } else if (top.length == 2) {
      top.add({});
    }
  }
}
