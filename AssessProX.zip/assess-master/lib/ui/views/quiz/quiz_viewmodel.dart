import 'package:assess/app/app.bottomsheets.dart';
import 'package:assess/ui/common/uihelper/snakbar_helper.dart';
import 'package:assess/ui/views/leaderboard/leaderboard_view.dart';
import 'package:assess/ui/views/newquiz/newquiz_view.dart';
import 'package:assess/ui/views/polling/polling_view.dart';
import 'package:assess/ui/views/reports/reports_view.dart';
import 'package:assess/ui/views/solvequiz/solvequiz_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.dialogs.dart';
import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';

class QuizViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final _bottomService = locator<BottomSheetService>();
  final _dialogService = locator<DialogService>();

  TextEditingController search = TextEditingController();

  void next(Map data) {
    _bottomService.showCustomSheet(variant: BottomSheetType.notice, data: data);
  }

  void leaderboard(String pin) {
    _navigationService.navigateWithTransition(
        LeaderboardView(
          pin: pin,
        ),
        routeName: Routes.leaderboardView,
        transitionStyle: Transition.rightToLeft);
  }

  void close() {
    search.clear();
    notifyListeners();
  }

  void scan(BuildContext context) {
    _dialogService
        .showCustomDialog(variant: DialogType.infoAlert)
        .then((value) {
      if (value!.data['pin'] == '') {
        show_snackbar(context, "No Qr Scan");
      } else {
        _navigationService.navigateWithTransition(
            SolvequizView(
              pin: value.data['pin'],
            ),
            routeName: Routes.solvequizView,
            transitionStyle: Transition.rightToLeft);
      }
    });
  }

  void startquiz(String pin) {
    _navigationService.navigateWithTransition(
        SolvequizView(
          pin: pin,
        ),
        routeName: Routes.solvequizView,
        transitionStyle: Transition.rightToLeft);
  }

  void newquiz() {
    _navigationService.navigateWithTransition(const NewquizView(),
        routeName: Routes.newquizView, transitionStyle: Transition.rightToLeft);
  }

  void poll() {
    _navigationService.navigateWithTransition(const PollingView(),
        routeName: Routes.pollingView, transitionStyle: Transition.rightToLeft);
  }

  void description() {
    _navigationService.navigateWithTransition(ReportsView(),
        routeName: Routes.reportsView, transitionStyle: Transition.rightToLeft);
  }
}
