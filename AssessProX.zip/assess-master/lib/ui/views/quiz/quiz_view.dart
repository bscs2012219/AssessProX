import 'package:assess/ui/common/apihelpers/apihelper.dart';
import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/app_strings.dart';
import 'package:assess/ui/common/ui_helpers.dart';
import 'package:assess/ui/common/uihelper/snakbar_helper.dart';
import 'package:assess/ui/common/uihelper/text_helper.dart';
import 'package:assess/ui/widgets/common/recomendedquiz/recomendedquiz.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:stacked/stacked.dart';

import '../../widgets/common/quizlistimg/quizlistimg.dart';
import '../../widgets/common/quizlistinnerdata/quizlistinnerdata.dart';
import '../../widgets/common/tophelper/tophelper.dart';
import 'quiz_viewmodel.dart';

class QuizView extends StackedView<QuizViewModel> {
  const QuizView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    QuizViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.fromLTRB(10, 15, 10, 10),
                padding: const EdgeInsets.symmetric(horizontal: 10),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(width: 2, color: kcLightGrey)),
                child: Row(
                  children: [
                    Expanded(
                        child: TextFormField(
                      controller: viewModel.search,
                      decoration: InputDecoration(
                        focusedBorder: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        counterText: "",
                        hintStyle: text_helper.customstyle(
                            poppins, kcLightGrey, fontSize14, context, false),
                        prefixIcon: const Icon(Icons.search),
                        border: InputBorder.none,
                        hintText: "search",
                      ),
                      style: text_helper.customstyle(
                          poppins, kcPrimaryColor, fontSize14, context, false),
                      onChanged: (val) {
                        viewModel.notifyListeners();
                      },
                    )).animate(delay: 300.ms).fade(),
                    horizontalSpaceTiny,
                    InkWell(
                        onTap: () => viewModel.close(),
                        child: const Icon(
                          Icons.close,
                          color: kcPrimaryColor,
                        )).animate(delay: 300.ms).fade(),
                    horizontalSpaceTiny
                  ],
                ),
              ),
              Container(
                width: screenWidth(context),
                padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
                margin: const EdgeInsets.fromLTRB(10, 5, 10, 5),
                child: Row(
                  children: [
                    Tophelper(
                      function: () => viewModel.newquiz(),
                      icon: "assets/add.png",
                      text: "Add\nQuiz",
                    ),
                    horizontalSpaceSmall,
                    Tophelper(
                        function: () => viewModel.scan(context),
                        icon: "assets/qr.png",
                        text: "Scan\nQuiz"),
                    horizontalSpaceSmall,
                    Tophelper(
                        function: () => viewModel.poll(),
                        icon: "assets/polling.png",
                        text: "Your\nPolling"),
                    horizontalSpaceSmall,
                    Tophelper(
                        function: () => viewModel.description(),
                        icon: "assets/analytics.png",
                        text: "Your\nReports"),
                  ],
                ),
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 5, 0, 0),
                  child: text_helper(
                    data: "Recommended Quizzes",
                    font: poppins,
                    color: kcDarkGreyColor,
                    size: fontSize14,
                    bold: true,
                  ),
                ),
              ).animate(delay: 700.ms).fade().moveY(begin: 50, end: 0),
              const Recomendedquiz()
                  .animate(delay: 900.ms)
                  .fade()
                  .moveY(begin: 50, end: 0),
              Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 5, 0, 0),
                  child: text_helper(
                    data: "All Quizzes",
                    font: poppins,
                    color: kcDarkGreyColor,
                    size: fontSize14,
                    bold: true,
                  ),
                ),
              ).animate(delay: 1100.ms).fade().moveY(begin: 50, end: 0),
              Expanded(
                child: FutureBuilder(
                    future: ApiHelper.allquiz(),
                    builder: (BuildContext context, AsyncSnapshot snapshot) {
                      if (snapshot.hasData) {
                        return ListView.builder(
                          itemCount: snapshot.data.length,
                          itemBuilder: (BuildContext context, int index) {
                            if (snapshot.data[index]['title']
                                .toString()
                                .trim()
                                .toLowerCase()
                                .contains(viewModel.search.text
                                    .toString()
                                    .trim()
                                    .toLowerCase())) {
                              return listdataview(
                                  context, snapshot.data[index], viewModel);
                            } else {
                              return const SizedBox.shrink();
                            }
                          },
                        );
                      } else if (snapshot.hasError) {
                        return const Icon(Icons.error_outline);
                      } else {
                        return displaysimpleprogress(context);
                      }
                    }),
              ),
            ],
          ),
        ));
  }

  Widget listdataview(BuildContext context, Map data, QuizViewModel viewModel) {
    return InkWell(
      onTap: () => viewModel.next(data),
      child: Container(
        margin: const EdgeInsets.all(10),
        padding: const EdgeInsets.all(10),
        height: 130,
        width: screenWidth(context),
        child: Row(
          children: [
            Quizlistimg(
              information: data['pin'],
              size: 0.2,
            ).animate(delay: 1300.ms).fade().moveY(begin: 50, end: 0),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    text_helper(
                      data: data['title'].toString().toUpperCase(),
                      font: poppins,
                      color: kcPrimaryColor,
                      size: fontSize12,
                      overflow: TextOverflow.ellipsis,
                      bold: true,
                    ).animate(delay: 1500.ms).fade().moveY(begin: 50, end: 0),
                    text_helper(
                      data: data['des'].toString().toUpperCase(),
                      font: poppins,
                      lines: 1,
                      color: kcLightGrey,
                      size: fontSize10,
                      overflow: TextOverflow.ellipsis,
                      bold: true,
                    ).animate(delay: 1500.ms).fade().moveY(begin: 50, end: 0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Quizlistinnerdata(
                            txt: data['subject'].toString().toUpperCase(),
                            iconData: "assets/subject.png"),
                        Quizlistinnerdata(
                            txt: data['duration'].toString().toUpperCase(),
                            iconData: "assets/duration.png"),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Quizlistinnerdata(
                            txt: data['questionanswer']
                                .length
                                .toString()
                                .toUpperCase(),
                            iconData: "assets/questions.png"),
                        Quizlistinnerdata(
                            txt: data['user'].toString().toUpperCase(),
                            iconData: "assets/user.png"),
                      ],
                    )
                  ],
                ),
              ),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                InkWell(
                  onTap: () => viewModel.leaderboard(data['pin']),
                  child: Container(
                    padding: const EdgeInsets.all(5),
                    // decoration: BoxDecoration(
                    //     borderRadius: BorderRadius.circular(10),
                    //     color: getColorWithOpacity(kcPrimaryColor, 0.2)),
                    child: Image.asset(
                      "assets/leaderboardicon.png",
                      width: screenWidthCustom(context, 0.08),
                      height: screenWidthCustom(context, 0.08),
                    ).animate(delay: 2300.ms).fade().moveY(begin: 50, end: 0),
                  ).animate(delay: 2100.ms).fade().moveY(begin: 50, end: 0),
                ),
                InkWell(
                  onTap: () => viewModel.startquiz(data['pin']),
                  child: Container(
                    padding: const EdgeInsets.all(5),
                    // decoration: BoxDecoration(
                    //     borderRadius: BorderRadius.circular(10),
                    //     color: getColorWithOpacity(kcPrimaryColor, 0.2)),
                    child: Image.asset(
                      "assets/arrowf.png",
                      width: screenWidthCustom(context, 0.08),
                      height: screenWidthCustom(context, 0.08),
                    ).animate(delay: 2300.ms).fade().moveY(begin: 50, end: 0),
                  ).animate(delay: 2100.ms).fade().moveY(begin: 50, end: 0),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  @override
  QuizViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      QuizViewModel();
}
