// ignore_for_file: prefer_interpolation_to_compose_strings

import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/app_strings.dart';
import 'package:assess/ui/common/ui_helpers.dart';
import 'package:assess/ui/common/uihelper/text_helper.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../common/apihelpers/apihelper.dart';
import '../../common/uihelper/snakbar_helper.dart';
import '../../widgets/common/customslider/customslider.dart';
import '../../widgets/common/tophelper/tophelper.dart';
import 'marketplace_viewmodel.dart';

class MarketplaceView extends StackedView<MarketplaceViewModel> {
  MarketplaceView({Key? key, this.isback = true}) : super(key: key);
  bool isback;

  @override
  Widget builder(
    BuildContext context,
    MarketplaceViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: Column(
            children: [
              top(context, viewModel),
              Expanded(
                child: FutureBuilder(
                  future: ApiHelper.getallmarket(),
                  builder: (BuildContext context, AsyncSnapshot snapshot) {
                    if (snapshot.hasData) {
                      return GridView.builder(
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 5.0,
                          mainAxisSpacing: 5.0,
                        ),
                        itemCount: snapshot.data.length,
                        itemBuilder: (BuildContext context, int index) {
                          return InkWell(
                            onTap: () =>
                                viewModel.next(snapshot.data[index] as Map),
                            child: Container(
                              width: screenWidth(context),
                              padding: const EdgeInsets.all(10),
                              margin: const EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: getColorWithOpacity(golden, 0.1)),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Customslider(
                                      data: snapshot.data[index]['url'],
                                      h: 0.25),
                                  verticalSpaceTiny,
                                  InkWell(
                                    child: text_helper(
                                      data: snapshot.data[index]['title'],
                                      font: poppins,
                                      color: kcPrimaryColor,
                                      size: fontSize14,
                                      bold: true,
                                    ),
                                  ),
                                  text_helper(
                                    data: "\$ " + snapshot.data[index]['price'],
                                    font: poppins,
                                    color: golden,
                                    size: fontSize12,
                                    bold: true,
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    } else if (snapshot.hasError) {
                      return const Icon(
                        Icons.error,
                        color: kcDarkGreyColor,
                      );
                    } else {
                      return displaysimpleprogress(context);
                    }
                  },
                ),
              )
            ],
          ),
        ));
  }

  Widget top(BuildContext context, MarketplaceViewModel viewModel) {
    return Container(
      width: screenWidth(context),
      padding: const EdgeInsets.all(10),
      margin: const EdgeInsets.all(10),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: getColorWithOpacity(kcLightGrey, 0.1)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              isback
                  ? Tophelper(
                      function: () => viewModel.back(),
                      icon: "assets/arrowb.png")
                  : const SizedBox.shrink(),
              horizontalSpaceSmall,
              text_helper(
                data: "Market Place",
                font: poppins,
                color: kcPrimaryColor,
                size: fontSize14,
                bold: true,
              ),
            ],
          ),
          Row(
            children: [
              Tophelper(
                  function: () => viewModel.myorders(),
                  icon: "assets/download.png"),
              horizontalSpaceSmall,
              Tophelper(
                  function: () => viewModel.add(), icon: "assets/add22.png")
            ],
          ),
        ],
      ),
    );
  }

  @override
  MarketplaceViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      MarketplaceViewModel();
}
