import 'package:assess/ui/views/buying/buying_view.dart';
import 'package:assess/ui/views/download/download_view.dart';
import 'package:assess/ui/views/marketplaceaddgoods/marketplaceaddgoods_view.dart';
import 'package:assess/ui/views/myorders/myorders_view.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../services/sharedpref_service.dart';

class MarketplaceViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final _sharedpref = locator<SharedprefService>();

  void next(Map data) {
    if (List.of(data['users']).contains(_sharedpref.readString('number'))) {
      _navigationService.navigateWithTransition(
          DownloadView(
            url: data['url'],
          ),
          routeName: Routes.downloadView,
          transitionStyle: Transition.rightToLeft);
    } else {
      _navigationService.navigateWithTransition(
          BuyingView(
            data: data,
          ),
          routeName: Routes.buyingView,
          transitionStyle: Transition.rightToLeft);
    }
  }

  void myorders() {
    _navigationService.navigateWithTransition(const MyordersView(),
        routeName: Routes.myordersView,
        transitionStyle: Transition.rightToLeft);
  }

  void add() {
    _navigationService.navigateWithTransition(const MarketplaceaddgoodsView(),
        routeName: Routes.marketplaceaddgoodsView,
        transitionStyle: Transition.rightToLeft);
  }

  void back() {
    _navigationService.back();
  }
}
