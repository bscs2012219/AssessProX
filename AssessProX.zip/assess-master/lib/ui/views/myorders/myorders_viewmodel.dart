import 'package:assess/ui/views/download/download_view.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../services/sharedpref_service.dart';

class MyordersViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final sharedpref = locator<SharedprefService>();

  void view(List url) {
    _navigationService.navigateWithTransition(
        DownloadView(
          url: url,
        ),
        routeName: Routes.downloadView,
        transitionStyle: Transition.rightToLeft);
  }
}
