import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/app_strings.dart';
import 'package:assess/ui/common/ui_helpers.dart';
import 'package:assess/ui/common/uihelper/text_helper.dart';
import 'package:assess/ui/widgets/common/top/top.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../common/apihelpers/apihelper.dart';
import '../../common/uihelper/snakbar_helper.dart';
import 'myorders_viewmodel.dart';

class MyordersView extends StackedView<MyordersViewModel> {
  const MyordersView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    MyordersViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: Column(
            children: [
              Top(title: "My Orders"),
              Expanded(
                child: FutureBuilder(
                  future: ApiHelper.getallmarketbynumber(
                      viewModel.sharedpref.readString('number')),
                  builder: (BuildContext context, AsyncSnapshot snapshot) {
                    if (snapshot.hasData) {
                      return ListView.builder(
                        itemCount: snapshot.data.length,
                        itemBuilder: (BuildContext context, int index) {
                          return InkWell(
                            onTap: () =>
                                viewModel.view(snapshot.data[index]['url']),
                            child: Container(
                              width: screenWidth(context),
                              padding: const EdgeInsets.all(10),
                              margin: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                  color: getColorWithOpacity(kcLightGrey, 0.1),
                                  borderRadius: BorderRadius.circular(10)),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        text_helper(
                                          data: snapshot.data[index]['title'],
                                          font: poppins,
                                          color: kcPrimaryColor,
                                          size: fontSize14,
                                          bold: true,
                                        ),
                                        text_helper(
                                          data: snapshot.data[index]['des'],
                                          font: poppins,
                                          color: kcLightGrey,
                                          size: fontSize10,
                                        ),
                                      ],
                                    ),
                                  ),
                                  const Icon(
                                    Icons.arrow_forward_ios_rounded,
                                    color: kcPrimaryColor,
                                  )
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    } else if (snapshot.hasError) {
                      return const Icon(
                        Icons.error,
                        color: kcDarkGreyColor,
                      );
                    } else {
                      return displaysimpleprogress(context);
                    }
                  },
                ),
              )
            ],
          ),
        ));
  }

  @override
  MyordersViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      MyordersViewModel();
}
