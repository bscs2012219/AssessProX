import 'package:flutter/material.dart';

import '../../widgets/common/top/top.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

class showpdf extends StatelessWidget {
  showpdf({super.key, required this.data});
  Map data;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Top(
              title: "Your Mock Pdf",
            ),
            Expanded(child: SfPdfViewer.network(data['pdf'] ?? data['data']))
          ],
        ),
      ),
    );
  }
}
