import 'package:assess/ui/common/apihelpers/apihelper.dart';
import 'package:assess/ui/common/app_colors.dart';
import 'package:assess/ui/common/app_strings.dart';
import 'package:assess/ui/common/ui_helpers.dart';
import 'package:assess/ui/common/uihelper/text_helper.dart';
import 'package:assess/ui/views/mocktest/showpdf.dart';
import 'package:assess/ui/widgets/common/newmocktest/newmocktest.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../common/uihelper/snakbar_helper.dart';
import '../../widgets/common/top/top.dart';
import '../../widgets/common/tophelper/tophelper.dart';
import 'mocktest_viewmodel.dart';

class MocktestView extends StackedView<MocktestViewModel> {
  const MocktestView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    MocktestViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: Column(
            children: [
              Top(
                title: "Mock Test",
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      catbtn(context, viewModel, "All"),
                      catbtn(context, viewModel, "My"),
                    ],
                  ),
                  Tophelper(
                      function: () => add(context, viewModel),
                      icon: "assets/add22.png")
                ],
              ),
              Expanded(
                child: FutureBuilder(
                  future: ApiHelper.allmocktest(),
                  builder: (BuildContext context, AsyncSnapshot snapshot) {
                    if (snapshot.hasData) {
                      if (snapshot.data.toString() == '[]') {
                        return Center(
                          child: text_helper(
                              data: "No Data",
                              font: poppins,
                              color: kcDarkGreyColor,
                              size: fontSize14),
                        );
                      } else {
                        return ListView.builder(
                          itemCount: snapshot.data.length,
                          itemBuilder: (BuildContext context, int index) {
                            if (viewModel.cat == "All") {
                              return listdate(snapshot.data[index], context);
                            } else if (viewModel.cat == "My") {
                              if (viewModel.sharedpref.readString("number") ==
                                  snapshot.data[index]['addedby']) {
                                return listdate(snapshot.data[index], context);
                              } else {
                                return const SizedBox.shrink();
                              }
                            } else {
                              return const SizedBox.shrink();
                            }
                          },
                        );
                      }
                    } else if (snapshot.hasError) {
                      return const Icon(
                        Icons.error,
                        color: kcDarkGreyColor,
                      );
                    } else {
                      return displaysimpleprogress(context);
                    }
                  },
                ),
              ),
            ],
          ),
        ));
  }

  Widget listdate(Map data, BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => showpdf(
                      data: data,
                    )));
      },
      child: Container(
          padding: const EdgeInsets.all(10),
          margin: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: getColorWithOpacity(golden, 0.1),
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Image.asset(
                    "assets/pdf.png",
                    width: 50,
                    height: 50,
                  ),
                  horizontalSpaceTiny,
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        text_helper(
                          data: data['title'],
                          font: poppins,
                          color: kcDarkGreyColor,
                          size: fontSize14,
                          bold: true,
                        ),
                        text_helper(
                            data: data['des'],
                            font: poppins,
                            textAlign: TextAlign.start,
                            color: kcDarkGreyColor,
                            size: fontSize12),
                      ],
                    ),
                  )
                ],
              ),
              verticalSpaceTiny,
              const Align(
                alignment: Alignment.centerRight,
                child: Icon(Icons.arrow_forward_ios_rounded),
              ),
              verticalSpaceTiny
            ],
          )),
    );
  }

  Widget catbtn(
      BuildContext context, MocktestViewModel viewModel, String text) {
    return InkWell(
      onTap: () {
        viewModel.cat = text;
        viewModel.notifyListeners();
      },
      child: Container(
        padding: const EdgeInsets.all(10),
        margin: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: viewModel.cat == text ? kcPrimaryColor : white,
          border: Border.all(color: kcPrimaryColor, width: 1),
        ),
        child: text_helper(
          data: text,
          font: poppins,
          color: viewModel.cat == text ? white : kcPrimaryColor,
          size: fontSize14,
          bold: true,
        ),
      ),
    );
  }

  Future<void> add(BuildContext context, MocktestViewModel viewModel) async {
    await showDialog(
        context: context,
        builder: (BuildContext context) {
          return const Dialog(
            backgroundColor: white,
            child: Newmocktest(),
          );
        });
    viewModel.notifyListeners();
  }

  @override
  MocktestViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      MocktestViewModel();
}
