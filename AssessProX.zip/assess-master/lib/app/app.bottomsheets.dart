// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// StackedBottomsheetGenerator
// **************************************************************************

import 'package:stacked_services/stacked_services.dart';

import 'app.locator.dart';
import '../ui/bottom_sheets/buy/buy_sheet.dart';
import '../ui/bottom_sheets/buy2/buy2_sheet.dart';
import '../ui/bottom_sheets/buying/buying_sheet.dart';
import '../ui/bottom_sheets/notice/notice_sheet.dart';

enum BottomSheetType {
  notice,
  buy,
  buy2,
  buying,
}

void setupBottomSheetUi() {
  final bottomsheetService = locator<BottomSheetService>();

  final Map<BottomSheetType, SheetBuilder> builders = {
    BottomSheetType.notice: (context, request, completer) =>
        NoticeSheet(request: request, completer: completer),
    BottomSheetType.buy: (context, request, completer) =>
        BuySheet(request: request, completer: completer),
    BottomSheetType.buy2: (context, request, completer) =>
        Buy2Sheet(request: request, completer: completer),
    BottomSheetType.buying: (context, request, completer) =>
        BuyingSheet(request: request, completer: completer),
  };

  bottomsheetService.setCustomSheetBuilders(builders);
}
