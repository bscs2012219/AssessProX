import 'package:assess/ui/bottom_sheets/notice/notice_sheet.dart';
import 'package:assess/ui/dialogs/info_alert/info_alert_dialog.dart';
import 'package:assess/ui/views/home/home_view.dart';
import 'package:assess/ui/views/startup/startup_view.dart';
import 'package:stacked/stacked_annotations.dart';
import 'package:stacked_services/stacked_services.dart';
import 'package:assess/services/fire_service.dart';
import 'package:assess/services/sharedpref_service.dart';
import 'package:assess/ui/views/login/login_view.dart';
import 'package:assess/ui/views/signup/signup_view.dart';
import 'package:assess/ui/views/otp/otp_view.dart';
import 'package:assess/ui/views/addpass/addpass_view.dart';
import 'package:assess/ui/views/addpic/addpic_view.dart';
import 'package:assess/ui/views/homedetail/homedetail_view.dart';
import 'package:assess/ui/views/quiz/quiz_view.dart';
import 'package:assess/ui/views/leaderboard/leaderboard_view.dart';
import 'package:assess/ui/views/newquiz/newquiz_view.dart';
import 'package:assess/ui/views/solvequiz/solvequiz_view.dart';
import 'package:assess/ui/views/polling/polling_view.dart';
import 'package:assess/ui/views/addedu/addedu_view.dart';
import 'package:assess/ui/views/marketplace/marketplace_view.dart';
import 'package:assess/ui/views/marketplaceaddgoods/marketplaceaddgoods_view.dart';
import 'package:assess/ui/views/download/download_view.dart';
import 'package:assess/ui/bottom_sheets/buy/buy_sheet.dart';
import 'package:assess/ui/bottom_sheets/buy2/buy2_sheet.dart';
import 'package:assess/ui/bottom_sheets/buying/buying_sheet.dart';
import 'package:assess/ui/views/buying/buying_view.dart';
import 'package:assess/ui/views/wallet/wallet_view.dart';
import 'package:assess/ui/views/myorders/myorders_view.dart';
import 'package:assess/ui/views/reports/reports_view.dart';
import 'package:assess/ui/views/mocktest/mocktest_view.dart';
import 'package:assess/ui/views/allclasses/allclasses_view.dart';
import 'package:assess/ui/views/innerclass/innerclass_view.dart';
// @stacked-import

@StackedApp(
  routes: [
    MaterialRoute(page: HomeView),
    MaterialRoute(page: StartupView),
    MaterialRoute(page: LoginView),
    MaterialRoute(page: SignupView),
    MaterialRoute(page: OtpView),
    MaterialRoute(page: AddpassView),
    MaterialRoute(page: AddpicView),
    MaterialRoute(page: HomedetailView),
    MaterialRoute(page: QuizView),
    MaterialRoute(page: LeaderboardView),
    MaterialRoute(page: NewquizView),
    MaterialRoute(page: SolvequizView),
    MaterialRoute(page: PollingView),
    MaterialRoute(page: AddeduView),
    MaterialRoute(page: MarketplaceView),
    MaterialRoute(page: MarketplaceaddgoodsView),
    MaterialRoute(page: DownloadView),
    MaterialRoute(page: BuyingView),
    MaterialRoute(page: WalletView),
    MaterialRoute(page: MyordersView),
    MaterialRoute(page: ReportsView),
    MaterialRoute(page: MocktestView),
    MaterialRoute(page: AllclassesView),
    MaterialRoute(page: InnerclassView),
// @stacked-route
  ],
  dependencies: [
    LazySingleton(classType: BottomSheetService),
    LazySingleton(classType: DialogService),
    LazySingleton(classType: NavigationService),
    LazySingleton(classType: FireService),
    LazySingleton(classType: SharedprefService),
// @stacked-service
  ],
  bottomsheets: [
    StackedBottomsheet(classType: NoticeSheet),
    StackedBottomsheet(classType: BuySheet),
    StackedBottomsheet(classType: Buy2Sheet),
    StackedBottomsheet(classType: BuyingSheet),
// @stacked-bottom-sheet
  ],
  dialogs: [
    StackedDialog(classType: InfoAlertDialog),
    // @stacked-dialog
  ],
)
class App {}
