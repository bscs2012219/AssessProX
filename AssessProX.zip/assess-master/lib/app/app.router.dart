// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// StackedNavigatorGenerator
// **************************************************************************

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:assess/ui/views/addedu/addedu_view.dart' as _i15;
import 'package:assess/ui/views/addpass/addpass_view.dart' as _i7;
import 'package:assess/ui/views/addpic/addpic_view.dart' as _i8;
import 'package:assess/ui/views/allclasses/allclasses_view.dart' as _i24;
import 'package:assess/ui/views/buying/buying_view.dart' as _i19;
import 'package:assess/ui/views/download/download_view.dart' as _i18;
import 'package:assess/ui/views/home/home_view.dart' as _i2;
import 'package:assess/ui/views/homedetail/homedetail_view.dart' as _i9;
import 'package:assess/ui/views/innerclass/innerclass_view.dart' as _i25;
import 'package:assess/ui/views/leaderboard/leaderboard_view.dart' as _i11;
import 'package:assess/ui/views/login/login_view.dart' as _i4;
import 'package:assess/ui/views/marketplace/marketplace_view.dart' as _i16;
import 'package:assess/ui/views/marketplaceaddgoods/marketplaceaddgoods_view.dart'
    as _i17;
import 'package:assess/ui/views/mocktest/mocktest_view.dart' as _i23;
import 'package:assess/ui/views/myorders/myorders_view.dart' as _i21;
import 'package:assess/ui/views/newquiz/newquiz_view.dart' as _i12;
import 'package:assess/ui/views/otp/otp_view.dart' as _i6;
import 'package:assess/ui/views/polling/polling_view.dart' as _i14;
import 'package:assess/ui/views/quiz/quiz_view.dart' as _i10;
import 'package:assess/ui/views/reports/reports_view.dart' as _i22;
import 'package:assess/ui/views/signup/signup_view.dart' as _i5;
import 'package:assess/ui/views/solvequiz/solvequiz_view.dart' as _i13;
import 'package:assess/ui/views/startup/startup_view.dart' as _i3;
import 'package:assess/ui/views/wallet/wallet_view.dart' as _i20;
import 'package:flutter/material.dart' as _i26;
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart' as _i1;
import 'package:stacked_services/stacked_services.dart' as _i27;

class Routes {
  static const homeView = '/home-view';

  static const startupView = '/startup-view';

  static const loginView = '/login-view';

  static const signupView = '/signup-view';

  static const otpView = '/otp-view';

  static const addpassView = '/addpass-view';

  static const addpicView = '/addpic-view';

  static const homedetailView = '/homedetail-view';

  static const quizView = '/quiz-view';

  static const leaderboardView = '/leaderboard-view';

  static const newquizView = '/newquiz-view';

  static const solvequizView = '/solvequiz-view';

  static const pollingView = '/polling-view';

  static const addeduView = '/addedu-view';

  static const marketplaceView = '/marketplace-view';

  static const marketplaceaddgoodsView = '/marketplaceaddgoods-view';

  static const downloadView = '/download-view';

  static const buyingView = '/buying-view';

  static const walletView = '/wallet-view';

  static const myordersView = '/myorders-view';

  static const reportsView = '/reports-view';

  static const mocktestView = '/mocktest-view';

  static const allclassesView = '/allclasses-view';

  static const innerclassView = '/innerclass-view';

  static const all = <String>{
    homeView,
    startupView,
    loginView,
    signupView,
    otpView,
    addpassView,
    addpicView,
    homedetailView,
    quizView,
    leaderboardView,
    newquizView,
    solvequizView,
    pollingView,
    addeduView,
    marketplaceView,
    marketplaceaddgoodsView,
    downloadView,
    buyingView,
    walletView,
    myordersView,
    reportsView,
    mocktestView,
    allclassesView,
    innerclassView,
  };
}

class StackedRouter extends _i1.RouterBase {
  final _routes = <_i1.RouteDef>[
    _i1.RouteDef(
      Routes.homeView,
      page: _i2.HomeView,
    ),
    _i1.RouteDef(
      Routes.startupView,
      page: _i3.StartupView,
    ),
    _i1.RouteDef(
      Routes.loginView,
      page: _i4.LoginView,
    ),
    _i1.RouteDef(
      Routes.signupView,
      page: _i5.SignupView,
    ),
    _i1.RouteDef(
      Routes.otpView,
      page: _i6.OtpView,
    ),
    _i1.RouteDef(
      Routes.addpassView,
      page: _i7.AddpassView,
    ),
    _i1.RouteDef(
      Routes.addpicView,
      page: _i8.AddpicView,
    ),
    _i1.RouteDef(
      Routes.homedetailView,
      page: _i9.HomedetailView,
    ),
    _i1.RouteDef(
      Routes.quizView,
      page: _i10.QuizView,
    ),
    _i1.RouteDef(
      Routes.leaderboardView,
      page: _i11.LeaderboardView,
    ),
    _i1.RouteDef(
      Routes.newquizView,
      page: _i12.NewquizView,
    ),
    _i1.RouteDef(
      Routes.solvequizView,
      page: _i13.SolvequizView,
    ),
    _i1.RouteDef(
      Routes.pollingView,
      page: _i14.PollingView,
    ),
    _i1.RouteDef(
      Routes.addeduView,
      page: _i15.AddeduView,
    ),
    _i1.RouteDef(
      Routes.marketplaceView,
      page: _i16.MarketplaceView,
    ),
    _i1.RouteDef(
      Routes.marketplaceaddgoodsView,
      page: _i17.MarketplaceaddgoodsView,
    ),
    _i1.RouteDef(
      Routes.downloadView,
      page: _i18.DownloadView,
    ),
    _i1.RouteDef(
      Routes.buyingView,
      page: _i19.BuyingView,
    ),
    _i1.RouteDef(
      Routes.walletView,
      page: _i20.WalletView,
    ),
    _i1.RouteDef(
      Routes.myordersView,
      page: _i21.MyordersView,
    ),
    _i1.RouteDef(
      Routes.reportsView,
      page: _i22.ReportsView,
    ),
    _i1.RouteDef(
      Routes.mocktestView,
      page: _i23.MocktestView,
    ),
    _i1.RouteDef(
      Routes.allclassesView,
      page: _i24.AllclassesView,
    ),
    _i1.RouteDef(
      Routes.innerclassView,
      page: _i25.InnerclassView,
    ),
  ];

  final _pagesMap = <Type, _i1.StackedRouteFactory>{
    _i2.HomeView: (data) {
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => const _i2.HomeView(),
        settings: data,
      );
    },
    _i3.StartupView: (data) {
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => const _i3.StartupView(),
        settings: data,
      );
    },
    _i4.LoginView: (data) {
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => const _i4.LoginView(),
        settings: data,
      );
    },
    _i5.SignupView: (data) {
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => const _i5.SignupView(),
        settings: data,
      );
    },
    _i6.OtpView: (data) {
      final args = data.getArgs<OtpViewArguments>(nullOk: false);
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => _i6.OtpView(key: args.key, id: args.id),
        settings: data,
      );
    },
    _i7.AddpassView: (data) {
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => const _i7.AddpassView(),
        settings: data,
      );
    },
    _i8.AddpicView: (data) {
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => const _i8.AddpicView(),
        settings: data,
      );
    },
    _i9.HomedetailView: (data) {
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => const _i9.HomedetailView(),
        settings: data,
      );
    },
    _i10.QuizView: (data) {
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => const _i10.QuizView(),
        settings: data,
      );
    },
    _i11.LeaderboardView: (data) {
      final args = data.getArgs<LeaderboardViewArguments>(nullOk: false);
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i11.LeaderboardView(key: args.key, pin: args.pin),
        settings: data,
      );
    },
    _i12.NewquizView: (data) {
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => const _i12.NewquizView(),
        settings: data,
      );
    },
    _i13.SolvequizView: (data) {
      final args = data.getArgs<SolvequizViewArguments>(nullOk: false);
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => _i13.SolvequizView(key: args.key, pin: args.pin),
        settings: data,
      );
    },
    _i14.PollingView: (data) {
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => const _i14.PollingView(),
        settings: data,
      );
    },
    _i15.AddeduView: (data) {
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => const _i15.AddeduView(),
        settings: data,
      );
    },
    _i16.MarketplaceView: (data) {
      final args = data.getArgs<MarketplaceViewArguments>(
        orElse: () => const MarketplaceViewArguments(),
      );
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i16.MarketplaceView(key: args.key, isback: args.isback),
        settings: data,
      );
    },
    _i17.MarketplaceaddgoodsView: (data) {
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => const _i17.MarketplaceaddgoodsView(),
        settings: data,
      );
    },
    _i18.DownloadView: (data) {
      final args = data.getArgs<DownloadViewArguments>(nullOk: false);
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => _i18.DownloadView(key: args.key, url: args.url),
        settings: data,
      );
    },
    _i19.BuyingView: (data) {
      final args = data.getArgs<BuyingViewArguments>(nullOk: false);
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => _i19.BuyingView(key: args.key, data: args.data),
        settings: data,
      );
    },
    _i20.WalletView: (data) {
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => const _i20.WalletView(),
        settings: data,
      );
    },
    _i21.MyordersView: (data) {
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => const _i21.MyordersView(),
        settings: data,
      );
    },
    _i22.ReportsView: (data) {
      final args = data.getArgs<ReportsViewArguments>(
        orElse: () => const ReportsViewArguments(),
      );
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i22.ReportsView(key: args.key, isback: args.isback),
        settings: data,
      );
    },
    _i23.MocktestView: (data) {
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => const _i23.MocktestView(),
        settings: data,
      );
    },
    _i24.AllclassesView: (data) {
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => const _i24.AllclassesView(),
        settings: data,
      );
    },
    _i25.InnerclassView: (data) {
      return _i26.MaterialPageRoute<dynamic>(
        builder: (context) => _i25.InnerclassView(
          id: "",
          admin: false,
          title: "",
        ),
        settings: data,
      );
    },
  };

  @override
  List<_i1.RouteDef> get routes => _routes;

  @override
  Map<Type, _i1.StackedRouteFactory> get pagesMap => _pagesMap;
}

class OtpViewArguments {
  const OtpViewArguments({
    this.key,
    required this.id,
  });

  final _i26.Key? key;

  final String id;

  @override
  String toString() {
    return '{"key": "$key", "id": "$id"}';
  }

  @override
  bool operator ==(covariant OtpViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.id == id;
  }

  @override
  int get hashCode {
    return key.hashCode ^ id.hashCode;
  }
}

class LeaderboardViewArguments {
  const LeaderboardViewArguments({
    this.key,
    required this.pin,
  });

  final _i26.Key? key;

  final String pin;

  @override
  String toString() {
    return '{"key": "$key", "pin": "$pin"}';
  }

  @override
  bool operator ==(covariant LeaderboardViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.pin == pin;
  }

  @override
  int get hashCode {
    return key.hashCode ^ pin.hashCode;
  }
}

class SolvequizViewArguments {
  const SolvequizViewArguments({
    this.key,
    required this.pin,
  });

  final _i26.Key? key;

  final String pin;

  @override
  String toString() {
    return '{"key": "$key", "pin": "$pin"}';
  }

  @override
  bool operator ==(covariant SolvequizViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.pin == pin;
  }

  @override
  int get hashCode {
    return key.hashCode ^ pin.hashCode;
  }
}

class MarketplaceViewArguments {
  const MarketplaceViewArguments({
    this.key,
    this.isback = true,
  });

  final _i26.Key? key;

  final bool isback;

  @override
  String toString() {
    return '{"key": "$key", "isback": "$isback"}';
  }

  @override
  bool operator ==(covariant MarketplaceViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.isback == isback;
  }

  @override
  int get hashCode {
    return key.hashCode ^ isback.hashCode;
  }
}

class DownloadViewArguments {
  const DownloadViewArguments({
    this.key,
    required this.url,
  });

  final _i26.Key? key;

  final List<dynamic> url;

  @override
  String toString() {
    return '{"key": "$key", "url": "$url"}';
  }

  @override
  bool operator ==(covariant DownloadViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.url == url;
  }

  @override
  int get hashCode {
    return key.hashCode ^ url.hashCode;
  }
}

class BuyingViewArguments {
  const BuyingViewArguments({
    this.key,
    required this.data,
  });

  final _i26.Key? key;

  final Map<dynamic, dynamic> data;

  @override
  String toString() {
    return '{"key": "$key", "data": "$data"}';
  }

  @override
  bool operator ==(covariant BuyingViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.data == data;
  }

  @override
  int get hashCode {
    return key.hashCode ^ data.hashCode;
  }
}

class ReportsViewArguments {
  const ReportsViewArguments({
    this.key,
    this.isback = true,
  });

  final _i26.Key? key;

  final bool isback;

  @override
  String toString() {
    return '{"key": "$key", "isback": "$isback"}';
  }

  @override
  bool operator ==(covariant ReportsViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.isback == isback;
  }

  @override
  int get hashCode {
    return key.hashCode ^ isback.hashCode;
  }
}

extension NavigatorStateExtension on _i27.NavigationService {
  Future<dynamic> navigateToHomeView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.homeView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToStartupView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.startupView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToLoginView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.loginView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToSignupView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.signupView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToOtpView({
    _i26.Key? key,
    required String id,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.otpView,
        arguments: OtpViewArguments(key: key, id: id),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToAddpassView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.addpassView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToAddpicView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.addpicView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToHomedetailView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.homedetailView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToQuizView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.quizView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToLeaderboardView({
    _i26.Key? key,
    required String pin,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.leaderboardView,
        arguments: LeaderboardViewArguments(key: key, pin: pin),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToNewquizView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.newquizView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToSolvequizView({
    _i26.Key? key,
    required String pin,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.solvequizView,
        arguments: SolvequizViewArguments(key: key, pin: pin),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToPollingView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.pollingView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToAddeduView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.addeduView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToMarketplaceView({
    _i26.Key? key,
    bool isback = true,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.marketplaceView,
        arguments: MarketplaceViewArguments(key: key, isback: isback),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToMarketplaceaddgoodsView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.marketplaceaddgoodsView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToDownloadView({
    _i26.Key? key,
    required List<dynamic> url,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.downloadView,
        arguments: DownloadViewArguments(key: key, url: url),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToBuyingView({
    _i26.Key? key,
    required Map<dynamic, dynamic> data,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.buyingView,
        arguments: BuyingViewArguments(key: key, data: data),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToWalletView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.walletView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToMyordersView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.myordersView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToReportsView({
    _i26.Key? key,
    bool isback = true,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.reportsView,
        arguments: ReportsViewArguments(key: key, isback: isback),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToMocktestView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.mocktestView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToAllclassesView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.allclassesView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToInnerclassView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.innerclassView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithHomeView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.homeView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithStartupView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.startupView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithLoginView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.loginView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithSignupView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.signupView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithOtpView({
    _i26.Key? key,
    required String id,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.otpView,
        arguments: OtpViewArguments(key: key, id: id),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithAddpassView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.addpassView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithAddpicView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.addpicView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithHomedetailView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.homedetailView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithQuizView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.quizView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithLeaderboardView({
    _i26.Key? key,
    required String pin,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.leaderboardView,
        arguments: LeaderboardViewArguments(key: key, pin: pin),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithNewquizView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.newquizView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithSolvequizView({
    _i26.Key? key,
    required String pin,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.solvequizView,
        arguments: SolvequizViewArguments(key: key, pin: pin),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithPollingView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.pollingView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithAddeduView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.addeduView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithMarketplaceView({
    _i26.Key? key,
    bool isback = true,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.marketplaceView,
        arguments: MarketplaceViewArguments(key: key, isback: isback),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithMarketplaceaddgoodsView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.marketplaceaddgoodsView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithDownloadView({
    _i26.Key? key,
    required List<dynamic> url,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.downloadView,
        arguments: DownloadViewArguments(key: key, url: url),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithBuyingView({
    _i26.Key? key,
    required Map<dynamic, dynamic> data,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.buyingView,
        arguments: BuyingViewArguments(key: key, data: data),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithWalletView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.walletView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithMyordersView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.myordersView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithReportsView({
    _i26.Key? key,
    bool isback = true,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.reportsView,
        arguments: ReportsViewArguments(key: key, isback: isback),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithMocktestView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.mocktestView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithAllclassesView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.allclassesView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithInnerclassView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.innerclassView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }
}
